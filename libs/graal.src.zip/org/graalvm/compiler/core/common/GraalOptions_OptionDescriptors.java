// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// Source: GraalOptions.java
package org.graalvm.compiler.core.common;

import java.util.*;
import org.graalvm.compiler.options.*;

public class GraalOptions_OptionDescriptors implements OptionDescriptors {
    @Override
    public OptionDescriptor get(String value) {
        // CheckStyle: stop line length check
        if (value.equals("AlwaysInlineVTableStubs")) {
            return OptionDescriptor.create("AlwaysInlineVTableStubs", Boolean.class, "", GraalOptions.class, "AlwaysInlineVTableStubs", GraalOptions.AlwaysInlineVTableStubs);
        }
        if (value.equals("CallArrayCopy")) {
            return OptionDescriptor.create("CallArrayCopy", Boolean.class, "", GraalOptions.class, "CallArrayCopy", GraalOptions.CallArrayCopy);
        }
        if (value.equals("CanOmitFrame")) {
            return OptionDescriptor.create("CanOmitFrame", Boolean.class, "", GraalOptions.class, "CanOmitFrame", GraalOptions.CanOmitFrame);
        }
        if (value.equals("ConditionalElimination")) {
            return OptionDescriptor.create("ConditionalElimination", Boolean.class, "", GraalOptions.class, "ConditionalElimination", GraalOptions.ConditionalElimination);
        }
        if (value.equals("DeoptALot")) {
            return OptionDescriptor.create("DeoptALot", Boolean.class, "", GraalOptions.class, "DeoptALot", GraalOptions.DeoptALot);
        }
        if (value.equals("DeoptsToDisableOptimisticOptimization")) {
            return OptionDescriptor.create("DeoptsToDisableOptimisticOptimization", Integer.class, "", GraalOptions.class, "DeoptsToDisableOptimisticOptimization", GraalOptions.DeoptsToDisableOptimisticOptimization);
        }
        if (value.equals("DetailedAsserts")) {
            return OptionDescriptor.create("DetailedAsserts", Boolean.class, "Enable expensive assertions.", GraalOptions.class, "DetailedAsserts", GraalOptions.DetailedAsserts);
        }
        if (value.equals("EagerSnippets")) {
            return OptionDescriptor.create("EagerSnippets", Boolean.class, "Eagerly construct extra snippet info.", GraalOptions.class, "EagerSnippets", GraalOptions.EagerSnippets);
        }
        if (value.equals("EscapeAnalysisIterations")) {
            return OptionDescriptor.create("EscapeAnalysisIterations", Integer.class, "", GraalOptions.class, "EscapeAnalysisIterations", GraalOptions.EscapeAnalysisIterations);
        }
        if (value.equals("EscapeAnalysisLoopCutoff")) {
            return OptionDescriptor.create("EscapeAnalysisLoopCutoff", Integer.class, "", GraalOptions.class, "EscapeAnalysisLoopCutoff", GraalOptions.EscapeAnalysisLoopCutoff);
        }
        if (value.equals("EscapeAnalyzeOnly")) {
            return OptionDescriptor.create("EscapeAnalyzeOnly", String.class, "", GraalOptions.class, "EscapeAnalyzeOnly", GraalOptions.EscapeAnalyzeOnly);
        }
        if (value.equals("FullUnroll")) {
            return OptionDescriptor.create("FullUnroll", Boolean.class, "", GraalOptions.class, "FullUnroll", GraalOptions.FullUnroll);
        }
        if (value.equals("GCDebugStartCycle")) {
            return OptionDescriptor.create("GCDebugStartCycle", Integer.class, "", GraalOptions.class, "GCDebugStartCycle", GraalOptions.GCDebugStartCycle);
        }
        if (value.equals("GenLoopSafepoints")) {
            return OptionDescriptor.create("GenLoopSafepoints", Boolean.class, "", GraalOptions.class, "GenLoopSafepoints", GraalOptions.GenLoopSafepoints);
        }
        if (value.equals("GenSafepoints")) {
            return OptionDescriptor.create("GenSafepoints", Boolean.class, "", GraalOptions.class, "GenSafepoints", GraalOptions.GenSafepoints);
        }
        if (value.equals("GeneratePIC")) {
            return OptionDescriptor.create("GeneratePIC", Boolean.class, "Generate position independent code", GraalOptions.class, "GeneratePIC", GraalOptions.GeneratePIC);
        }
        if (value.equals("HotSpotPrintInlining")) {
            return OptionDescriptor.create("HotSpotPrintInlining", Boolean.class, "Print inlining optimizations", GraalOptions.class, "HotSpotPrintInlining", GraalOptions.HotSpotPrintInlining);
        }
        if (value.equals("ImmutableCode")) {
            return OptionDescriptor.create("ImmutableCode", Boolean.class, "Try to avoid emitting code where patching is required", GraalOptions.class, "ImmutableCode", GraalOptions.ImmutableCode);
        }
        if (value.equals("InlineEverything")) {
            return OptionDescriptor.create("InlineEverything", Boolean.class, "", GraalOptions.class, "InlineEverything", GraalOptions.InlineEverything);
        }
        if (value.equals("InlineMegamorphicCalls")) {
            return OptionDescriptor.create("InlineMegamorphicCalls", Boolean.class, "Inline calls with megamorphic type profile (i.e., not all types could be recorded).", GraalOptions.class, "InlineMegamorphicCalls", GraalOptions.InlineMegamorphicCalls);
        }
        if (value.equals("InlineMonomorphicCalls")) {
            return OptionDescriptor.create("InlineMonomorphicCalls", Boolean.class, "Inline calls with monomorphic type profile.", GraalOptions.class, "InlineMonomorphicCalls", GraalOptions.InlineMonomorphicCalls);
        }
        if (value.equals("InlinePolymorphicCalls")) {
            return OptionDescriptor.create("InlinePolymorphicCalls", Boolean.class, "Inline calls with polymorphic type profile.", GraalOptions.class, "InlinePolymorphicCalls", GraalOptions.InlinePolymorphicCalls);
        }
        if (value.equals("InlineVTableStubs")) {
            return OptionDescriptor.create("InlineVTableStubs", Boolean.class, "", GraalOptions.class, "InlineVTableStubs", GraalOptions.InlineVTableStubs);
        }
        if (value.equals("Intrinsify")) {
            return OptionDescriptor.create("Intrinsify", Boolean.class, "Use compiler intrinsifications.", GraalOptions.class, "Intrinsify", GraalOptions.Intrinsify);
        }
        if (value.equals("LimitInlinedInvokes")) {
            return OptionDescriptor.create("LimitInlinedInvokes", Double.class, "", GraalOptions.class, "LimitInlinedInvokes", GraalOptions.LimitInlinedInvokes);
        }
        if (value.equals("LoopMaxUnswitch")) {
            return OptionDescriptor.create("LoopMaxUnswitch", Integer.class, "", GraalOptions.class, "LoopMaxUnswitch", GraalOptions.LoopMaxUnswitch);
        }
        if (value.equals("LoopPeeling")) {
            return OptionDescriptor.create("LoopPeeling", Boolean.class, "", GraalOptions.class, "LoopPeeling", GraalOptions.LoopPeeling);
        }
        if (value.equals("LoopUnswitch")) {
            return OptionDescriptor.create("LoopUnswitch", Boolean.class, "", GraalOptions.class, "LoopUnswitch", GraalOptions.LoopUnswitch);
        }
        if (value.equals("MatchExpressions")) {
            return OptionDescriptor.create("MatchExpressions", Boolean.class, "Allow backend to match complex expressions.", GraalOptions.class, "MatchExpressions", GraalOptions.MatchExpressions);
        }
        if (value.equals("MaximumDesiredSize")) {
            return OptionDescriptor.create("MaximumDesiredSize", Integer.class, "Maximum desired size of the compiler graph in nodes.", GraalOptions.class, "MaximumDesiredSize", GraalOptions.MaximumDesiredSize);
        }
        if (value.equals("MaximumEscapeAnalysisArrayLength")) {
            return OptionDescriptor.create("MaximumEscapeAnalysisArrayLength", Integer.class, "", GraalOptions.class, "MaximumEscapeAnalysisArrayLength", GraalOptions.MaximumEscapeAnalysisArrayLength);
        }
        if (value.equals("MaximumInliningSize")) {
            return OptionDescriptor.create("MaximumInliningSize", Integer.class, "Inlining is explored up to this number of nodes in the graph for each call site.", GraalOptions.class, "MaximumInliningSize", GraalOptions.MaximumInliningSize);
        }
        if (value.equals("MaximumRecursiveInlining")) {
            return OptionDescriptor.create("MaximumRecursiveInlining", Integer.class, "Maximum level of recursive inlining.", GraalOptions.class, "MaximumRecursiveInlining", GraalOptions.MaximumRecursiveInlining);
        }
        if (value.equals("MegamorphicInliningMinMethodProbability")) {
            return OptionDescriptor.create("MegamorphicInliningMinMethodProbability", Double.class, "Minimum probability for methods to be inlined for megamorphic type profiles.", GraalOptions.class, "MegamorphicInliningMinMethodProbability", GraalOptions.MegamorphicInliningMinMethodProbability);
        }
        if (value.equals("MinimumPeelProbability")) {
            return OptionDescriptor.create("MinimumPeelProbability", Float.class, "", GraalOptions.class, "MinimumPeelProbability", GraalOptions.MinimumPeelProbability);
        }
        if (value.equals("OmitHotExceptionStacktrace")) {
            return OptionDescriptor.create("OmitHotExceptionStacktrace", Boolean.class, "", GraalOptions.class, "OmitHotExceptionStacktrace", GraalOptions.OmitHotExceptionStacktrace);
        }
        if (value.equals("OptAssumptions")) {
            return OptionDescriptor.create("OptAssumptions", Boolean.class, "", GraalOptions.class, "OptAssumptions", GraalOptions.OptAssumptions);
        }
        if (value.equals("OptClearNonLiveLocals")) {
            return OptionDescriptor.create("OptClearNonLiveLocals", Boolean.class, "", GraalOptions.class, "OptClearNonLiveLocals", GraalOptions.OptClearNonLiveLocals);
        }
        if (value.equals("OptConvertDeoptsToGuards")) {
            return OptionDescriptor.create("OptConvertDeoptsToGuards", Boolean.class, "", GraalOptions.class, "OptConvertDeoptsToGuards", GraalOptions.OptConvertDeoptsToGuards);
        }
        if (value.equals("OptDeoptimizationGrouping")) {
            return OptionDescriptor.create("OptDeoptimizationGrouping", Boolean.class, "", GraalOptions.class, "OptDeoptimizationGrouping", GraalOptions.OptDeoptimizationGrouping);
        }
        if (value.equals("OptDevirtualizeInvokesOptimistically")) {
            return OptionDescriptor.create("OptDevirtualizeInvokesOptimistically", Boolean.class, "", GraalOptions.class, "OptDevirtualizeInvokesOptimistically", GraalOptions.OptDevirtualizeInvokesOptimistically);
        }
        if (value.equals("OptEliminateGuards")) {
            return OptionDescriptor.create("OptEliminateGuards", Boolean.class, "", GraalOptions.class, "OptEliminateGuards", GraalOptions.OptEliminateGuards);
        }
        if (value.equals("OptEliminatePartiallyRedundantGuards")) {
            return OptionDescriptor.create("OptEliminatePartiallyRedundantGuards", Boolean.class, "", GraalOptions.class, "OptEliminatePartiallyRedundantGuards", GraalOptions.OptEliminatePartiallyRedundantGuards);
        }
        if (value.equals("OptFilterProfiledTypes")) {
            return OptionDescriptor.create("OptFilterProfiledTypes", Boolean.class, "", GraalOptions.class, "OptFilterProfiledTypes", GraalOptions.OptFilterProfiledTypes);
        }
        if (value.equals("OptFloatingReads")) {
            return OptionDescriptor.create("OptFloatingReads", Boolean.class, "", GraalOptions.class, "OptFloatingReads", GraalOptions.OptFloatingReads);
        }
        if (value.equals("OptImplicitNullChecks")) {
            return OptionDescriptor.create("OptImplicitNullChecks", Boolean.class, "", GraalOptions.class, "OptImplicitNullChecks", GraalOptions.OptImplicitNullChecks);
        }
        if (value.equals("OptLoopTransform")) {
            return OptionDescriptor.create("OptLoopTransform", Boolean.class, "", GraalOptions.class, "OptLoopTransform", GraalOptions.OptLoopTransform);
        }
        if (value.equals("OptReadElimination")) {
            return OptionDescriptor.create("OptReadElimination", Boolean.class, "", GraalOptions.class, "OptReadElimination", GraalOptions.OptReadElimination);
        }
        if (value.equals("OptScheduleOutOfLoops")) {
            return OptionDescriptor.create("OptScheduleOutOfLoops", Boolean.class, "", GraalOptions.class, "OptScheduleOutOfLoops", GraalOptions.OptScheduleOutOfLoops);
        }
        if (value.equals("PEAInliningHints")) {
            return OptionDescriptor.create("PEAInliningHints", Boolean.class, "", GraalOptions.class, "PEAInliningHints", GraalOptions.PEAInliningHints);
        }
        if (value.equals("PartialEscapeAnalysis")) {
            return OptionDescriptor.create("PartialEscapeAnalysis", Boolean.class, "", GraalOptions.class, "PartialEscapeAnalysis", GraalOptions.PartialEscapeAnalysis);
        }
        if (value.equals("PrintProfilingInformation")) {
            return OptionDescriptor.create("PrintProfilingInformation", Boolean.class, "Print profiling information when parsing a method's bytecode", GraalOptions.class, "PrintProfilingInformation", GraalOptions.PrintProfilingInformation);
        }
        if (value.equals("RawConditionalElimination")) {
            return OptionDescriptor.create("RawConditionalElimination", Boolean.class, "", GraalOptions.class, "RawConditionalElimination", GraalOptions.RawConditionalElimination);
        }
        if (value.equals("ReadEliminationMaxLoopVisits")) {
            return OptionDescriptor.create("ReadEliminationMaxLoopVisits", Integer.class, "", GraalOptions.class, "ReadEliminationMaxLoopVisits", GraalOptions.ReadEliminationMaxLoopVisits);
        }
        if (value.equals("ReassociateInvariants")) {
            return OptionDescriptor.create("ReassociateInvariants", Boolean.class, "", GraalOptions.class, "ReassociateInvariants", GraalOptions.ReassociateInvariants);
        }
        if (value.equals("RegisterPressure")) {
            return OptionDescriptor.create("RegisterPressure", String.class, "Comma separated list of registers that register allocation is limited to.", GraalOptions.class, "RegisterPressure", GraalOptions.RegisterPressure);
        }
        if (value.equals("RemoveNeverExecutedCode")) {
            return OptionDescriptor.create("RemoveNeverExecutedCode", Boolean.class, "", GraalOptions.class, "RemoveNeverExecutedCode", GraalOptions.RemoveNeverExecutedCode);
        }
        if (value.equals("ReplaceInputsWithConstantsBasedOnStamps")) {
            return OptionDescriptor.create("ReplaceInputsWithConstantsBasedOnStamps", Boolean.class, "", GraalOptions.class, "ReplaceInputsWithConstantsBasedOnStamps", GraalOptions.ReplaceInputsWithConstantsBasedOnStamps);
        }
        if (value.equals("ResolveClassBeforeStaticInvoke")) {
            return OptionDescriptor.create("ResolveClassBeforeStaticInvoke", Boolean.class, "", GraalOptions.class, "ResolveClassBeforeStaticInvoke", GraalOptions.ResolveClassBeforeStaticInvoke);
        }
        if (value.equals("SmallCompiledLowLevelGraphSize")) {
            return OptionDescriptor.create("SmallCompiledLowLevelGraphSize", Integer.class, "If the previous low-level graph size of the method exceeds the threshold, it is not inlined.", GraalOptions.class, "SmallCompiledLowLevelGraphSize", GraalOptions.SmallCompiledLowLevelGraphSize);
        }
        if (value.equals("SnippetCounters")) {
            return OptionDescriptor.create("SnippetCounters", Boolean.class, "Enable counters for various paths in snippets.", GraalOptions.class, "SnippetCounters", GraalOptions.SnippetCounters);
        }
        if (value.equals("StressExplicitExceptionCode")) {
            return OptionDescriptor.create("StressExplicitExceptionCode", Boolean.class, "Stress the code emitting explicit exception throwing code.", GraalOptions.class, "StressExplicitExceptionCode", GraalOptions.StressExplicitExceptionCode);
        }
        if (value.equals("StressInvokeWithExceptionNode")) {
            return OptionDescriptor.create("StressInvokeWithExceptionNode", Boolean.class, "Stress the code emitting invokes with explicit exception edges.", GraalOptions.class, "StressInvokeWithExceptionNode", GraalOptions.StressInvokeWithExceptionNode);
        }
        if (value.equals("StressTestEarlyReads")) {
            return OptionDescriptor.create("StressTestEarlyReads", Boolean.class, "Stress the code by emitting reads at earliest instead of latest point.", GraalOptions.class, "StressTestEarlyReads", GraalOptions.StressTestEarlyReads);
        }
        if (value.equals("SupportJsrBytecodes")) {
            return OptionDescriptor.create("SupportJsrBytecodes", Boolean.class, "", GraalOptions.class, "SupportJsrBytecodes", GraalOptions.SupportJsrBytecodes);
        }
        if (value.equals("TailDuplicationProbability")) {
            return OptionDescriptor.create("TailDuplicationProbability", Double.class, "", GraalOptions.class, "TailDuplicationProbability", GraalOptions.TailDuplicationProbability);
        }
        if (value.equals("TailDuplicationTrivialSize")) {
            return OptionDescriptor.create("TailDuplicationTrivialSize", Integer.class, "", GraalOptions.class, "TailDuplicationTrivialSize", GraalOptions.TailDuplicationTrivialSize);
        }
        if (value.equals("TraceEscapeAnalysis")) {
            return OptionDescriptor.create("TraceEscapeAnalysis", Boolean.class, "", GraalOptions.class, "TraceEscapeAnalysis", GraalOptions.TraceEscapeAnalysis);
        }
        if (value.equals("TraceRA")) {
            return OptionDescriptor.create("TraceRA", Boolean.class, "Enable experimental Trace Register Allocation.", GraalOptions.class, "TraceRA", GraalOptions.TraceRA);
        }
        if (value.equals("TrivialInliningSize")) {
            return OptionDescriptor.create("TrivialInliningSize", Integer.class, "Graphs with less than this number of nodes are trivial and therefore always inlined.", GraalOptions.class, "TrivialInliningSize", GraalOptions.TrivialInliningSize);
        }
        if (value.equals("UseExceptionProbability")) {
            return OptionDescriptor.create("UseExceptionProbability", Boolean.class, "", GraalOptions.class, "UseExceptionProbability", GraalOptions.UseExceptionProbability);
        }
        if (value.equals("UseLoopLimitChecks")) {
            return OptionDescriptor.create("UseLoopLimitChecks", Boolean.class, "", GraalOptions.class, "UseLoopLimitChecks", GraalOptions.UseLoopLimitChecks);
        }
        if (value.equals("UseSnippetGraphCache")) {
            return OptionDescriptor.create("UseSnippetGraphCache", Boolean.class, "Use a cache for snippet graphs.", GraalOptions.class, "UseSnippetGraphCache", GraalOptions.UseSnippetGraphCache);
        }
        if (value.equals("UseTypeCheckHints")) {
            return OptionDescriptor.create("UseTypeCheckHints", Boolean.class, "", GraalOptions.class, "UseTypeCheckHints", GraalOptions.UseTypeCheckHints);
        }
        if (value.equals("VerifyHeapAtReturn")) {
            return OptionDescriptor.create("VerifyHeapAtReturn", Boolean.class, "Perform platform dependent validation of the Java heap at returns", GraalOptions.class, "VerifyHeapAtReturn", GraalOptions.VerifyHeapAtReturn);
        }
        if (value.equals("VerifyPhases")) {
            return OptionDescriptor.create("VerifyPhases", Boolean.class, "", GraalOptions.class, "VerifyPhases", GraalOptions.VerifyPhases);
        }
        if (value.equals("ZapStackOnMethodEntry")) {
            return OptionDescriptor.create("ZapStackOnMethodEntry", Boolean.class, "", GraalOptions.class, "ZapStackOnMethodEntry", GraalOptions.ZapStackOnMethodEntry);
        }
        // CheckStyle: resume line length check
        return null;
    }

    @Override
    public Iterator<OptionDescriptor> iterator() {
        // CheckStyle: stop line length check
        List<OptionDescriptor> options = Arrays.asList(
            OptionDescriptor.create("AlwaysInlineVTableStubs", Boolean.class, "", GraalOptions.class, "AlwaysInlineVTableStubs", GraalOptions.AlwaysInlineVTableStubs),
            OptionDescriptor.create("CallArrayCopy", Boolean.class, "", GraalOptions.class, "CallArrayCopy", GraalOptions.CallArrayCopy),
            OptionDescriptor.create("CanOmitFrame", Boolean.class, "", GraalOptions.class, "CanOmitFrame", GraalOptions.CanOmitFrame),
            OptionDescriptor.create("ConditionalElimination", Boolean.class, "", GraalOptions.class, "ConditionalElimination", GraalOptions.ConditionalElimination),
            OptionDescriptor.create("DeoptALot", Boolean.class, "", GraalOptions.class, "DeoptALot", GraalOptions.DeoptALot),
            OptionDescriptor.create("DeoptsToDisableOptimisticOptimization", Integer.class, "", GraalOptions.class, "DeoptsToDisableOptimisticOptimization", GraalOptions.DeoptsToDisableOptimisticOptimization),
            OptionDescriptor.create("DetailedAsserts", Boolean.class, "Enable expensive assertions.", GraalOptions.class, "DetailedAsserts", GraalOptions.DetailedAsserts),
            OptionDescriptor.create("EagerSnippets", Boolean.class, "Eagerly construct extra snippet info.", GraalOptions.class, "EagerSnippets", GraalOptions.EagerSnippets),
            OptionDescriptor.create("EscapeAnalysisIterations", Integer.class, "", GraalOptions.class, "EscapeAnalysisIterations", GraalOptions.EscapeAnalysisIterations),
            OptionDescriptor.create("EscapeAnalysisLoopCutoff", Integer.class, "", GraalOptions.class, "EscapeAnalysisLoopCutoff", GraalOptions.EscapeAnalysisLoopCutoff),
            OptionDescriptor.create("EscapeAnalyzeOnly", String.class, "", GraalOptions.class, "EscapeAnalyzeOnly", GraalOptions.EscapeAnalyzeOnly),
            OptionDescriptor.create("FullUnroll", Boolean.class, "", GraalOptions.class, "FullUnroll", GraalOptions.FullUnroll),
            OptionDescriptor.create("GCDebugStartCycle", Integer.class, "", GraalOptions.class, "GCDebugStartCycle", GraalOptions.GCDebugStartCycle),
            OptionDescriptor.create("GenLoopSafepoints", Boolean.class, "", GraalOptions.class, "GenLoopSafepoints", GraalOptions.GenLoopSafepoints),
            OptionDescriptor.create("GenSafepoints", Boolean.class, "", GraalOptions.class, "GenSafepoints", GraalOptions.GenSafepoints),
            OptionDescriptor.create("GeneratePIC", Boolean.class, "Generate position independent code", GraalOptions.class, "GeneratePIC", GraalOptions.GeneratePIC),
            OptionDescriptor.create("HotSpotPrintInlining", Boolean.class, "Print inlining optimizations", GraalOptions.class, "HotSpotPrintInlining", GraalOptions.HotSpotPrintInlining),
            OptionDescriptor.create("ImmutableCode", Boolean.class, "Try to avoid emitting code where patching is required", GraalOptions.class, "ImmutableCode", GraalOptions.ImmutableCode),
            OptionDescriptor.create("InlineEverything", Boolean.class, "", GraalOptions.class, "InlineEverything", GraalOptions.InlineEverything),
            OptionDescriptor.create("InlineMegamorphicCalls", Boolean.class, "Inline calls with megamorphic type profile (i.e., not all types could be recorded).", GraalOptions.class, "InlineMegamorphicCalls", GraalOptions.InlineMegamorphicCalls),
            OptionDescriptor.create("InlineMonomorphicCalls", Boolean.class, "Inline calls with monomorphic type profile.", GraalOptions.class, "InlineMonomorphicCalls", GraalOptions.InlineMonomorphicCalls),
            OptionDescriptor.create("InlinePolymorphicCalls", Boolean.class, "Inline calls with polymorphic type profile.", GraalOptions.class, "InlinePolymorphicCalls", GraalOptions.InlinePolymorphicCalls),
            OptionDescriptor.create("InlineVTableStubs", Boolean.class, "", GraalOptions.class, "InlineVTableStubs", GraalOptions.InlineVTableStubs),
            OptionDescriptor.create("Intrinsify", Boolean.class, "Use compiler intrinsifications.", GraalOptions.class, "Intrinsify", GraalOptions.Intrinsify),
            OptionDescriptor.create("LimitInlinedInvokes", Double.class, "", GraalOptions.class, "LimitInlinedInvokes", GraalOptions.LimitInlinedInvokes),
            OptionDescriptor.create("LoopMaxUnswitch", Integer.class, "", GraalOptions.class, "LoopMaxUnswitch", GraalOptions.LoopMaxUnswitch),
            OptionDescriptor.create("LoopPeeling", Boolean.class, "", GraalOptions.class, "LoopPeeling", GraalOptions.LoopPeeling),
            OptionDescriptor.create("LoopUnswitch", Boolean.class, "", GraalOptions.class, "LoopUnswitch", GraalOptions.LoopUnswitch),
            OptionDescriptor.create("MatchExpressions", Boolean.class, "Allow backend to match complex expressions.", GraalOptions.class, "MatchExpressions", GraalOptions.MatchExpressions),
            OptionDescriptor.create("MaximumDesiredSize", Integer.class, "Maximum desired size of the compiler graph in nodes.", GraalOptions.class, "MaximumDesiredSize", GraalOptions.MaximumDesiredSize),
            OptionDescriptor.create("MaximumEscapeAnalysisArrayLength", Integer.class, "", GraalOptions.class, "MaximumEscapeAnalysisArrayLength", GraalOptions.MaximumEscapeAnalysisArrayLength),
            OptionDescriptor.create("MaximumInliningSize", Integer.class, "Inlining is explored up to this number of nodes in the graph for each call site.", GraalOptions.class, "MaximumInliningSize", GraalOptions.MaximumInliningSize),
            OptionDescriptor.create("MaximumRecursiveInlining", Integer.class, "Maximum level of recursive inlining.", GraalOptions.class, "MaximumRecursiveInlining", GraalOptions.MaximumRecursiveInlining),
            OptionDescriptor.create("MegamorphicInliningMinMethodProbability", Double.class, "Minimum probability for methods to be inlined for megamorphic type profiles.", GraalOptions.class, "MegamorphicInliningMinMethodProbability", GraalOptions.MegamorphicInliningMinMethodProbability),
            OptionDescriptor.create("MinimumPeelProbability", Float.class, "", GraalOptions.class, "MinimumPeelProbability", GraalOptions.MinimumPeelProbability),
            OptionDescriptor.create("OmitHotExceptionStacktrace", Boolean.class, "", GraalOptions.class, "OmitHotExceptionStacktrace", GraalOptions.OmitHotExceptionStacktrace),
            OptionDescriptor.create("OptAssumptions", Boolean.class, "", GraalOptions.class, "OptAssumptions", GraalOptions.OptAssumptions),
            OptionDescriptor.create("OptClearNonLiveLocals", Boolean.class, "", GraalOptions.class, "OptClearNonLiveLocals", GraalOptions.OptClearNonLiveLocals),
            OptionDescriptor.create("OptConvertDeoptsToGuards", Boolean.class, "", GraalOptions.class, "OptConvertDeoptsToGuards", GraalOptions.OptConvertDeoptsToGuards),
            OptionDescriptor.create("OptDeoptimizationGrouping", Boolean.class, "", GraalOptions.class, "OptDeoptimizationGrouping", GraalOptions.OptDeoptimizationGrouping),
            OptionDescriptor.create("OptDevirtualizeInvokesOptimistically", Boolean.class, "", GraalOptions.class, "OptDevirtualizeInvokesOptimistically", GraalOptions.OptDevirtualizeInvokesOptimistically),
            OptionDescriptor.create("OptEliminateGuards", Boolean.class, "", GraalOptions.class, "OptEliminateGuards", GraalOptions.OptEliminateGuards),
            OptionDescriptor.create("OptEliminatePartiallyRedundantGuards", Boolean.class, "", GraalOptions.class, "OptEliminatePartiallyRedundantGuards", GraalOptions.OptEliminatePartiallyRedundantGuards),
            OptionDescriptor.create("OptFilterProfiledTypes", Boolean.class, "", GraalOptions.class, "OptFilterProfiledTypes", GraalOptions.OptFilterProfiledTypes),
            OptionDescriptor.create("OptFloatingReads", Boolean.class, "", GraalOptions.class, "OptFloatingReads", GraalOptions.OptFloatingReads),
            OptionDescriptor.create("OptImplicitNullChecks", Boolean.class, "", GraalOptions.class, "OptImplicitNullChecks", GraalOptions.OptImplicitNullChecks),
            OptionDescriptor.create("OptLoopTransform", Boolean.class, "", GraalOptions.class, "OptLoopTransform", GraalOptions.OptLoopTransform),
            OptionDescriptor.create("OptReadElimination", Boolean.class, "", GraalOptions.class, "OptReadElimination", GraalOptions.OptReadElimination),
            OptionDescriptor.create("OptScheduleOutOfLoops", Boolean.class, "", GraalOptions.class, "OptScheduleOutOfLoops", GraalOptions.OptScheduleOutOfLoops),
            OptionDescriptor.create("PEAInliningHints", Boolean.class, "", GraalOptions.class, "PEAInliningHints", GraalOptions.PEAInliningHints),
            OptionDescriptor.create("PartialEscapeAnalysis", Boolean.class, "", GraalOptions.class, "PartialEscapeAnalysis", GraalOptions.PartialEscapeAnalysis),
            OptionDescriptor.create("PrintProfilingInformation", Boolean.class, "Print profiling information when parsing a method's bytecode", GraalOptions.class, "PrintProfilingInformation", GraalOptions.PrintProfilingInformation),
            OptionDescriptor.create("RawConditionalElimination", Boolean.class, "", GraalOptions.class, "RawConditionalElimination", GraalOptions.RawConditionalElimination),
            OptionDescriptor.create("ReadEliminationMaxLoopVisits", Integer.class, "", GraalOptions.class, "ReadEliminationMaxLoopVisits", GraalOptions.ReadEliminationMaxLoopVisits),
            OptionDescriptor.create("ReassociateInvariants", Boolean.class, "", GraalOptions.class, "ReassociateInvariants", GraalOptions.ReassociateInvariants),
            OptionDescriptor.create("RegisterPressure", String.class, "Comma separated list of registers that register allocation is limited to.", GraalOptions.class, "RegisterPressure", GraalOptions.RegisterPressure),
            OptionDescriptor.create("RemoveNeverExecutedCode", Boolean.class, "", GraalOptions.class, "RemoveNeverExecutedCode", GraalOptions.RemoveNeverExecutedCode),
            OptionDescriptor.create("ReplaceInputsWithConstantsBasedOnStamps", Boolean.class, "", GraalOptions.class, "ReplaceInputsWithConstantsBasedOnStamps", GraalOptions.ReplaceInputsWithConstantsBasedOnStamps),
            OptionDescriptor.create("ResolveClassBeforeStaticInvoke", Boolean.class, "", GraalOptions.class, "ResolveClassBeforeStaticInvoke", GraalOptions.ResolveClassBeforeStaticInvoke),
            OptionDescriptor.create("SmallCompiledLowLevelGraphSize", Integer.class, "If the previous low-level graph size of the method exceeds the threshold, it is not inlined.", GraalOptions.class, "SmallCompiledLowLevelGraphSize", GraalOptions.SmallCompiledLowLevelGraphSize),
            OptionDescriptor.create("SnippetCounters", Boolean.class, "Enable counters for various paths in snippets.", GraalOptions.class, "SnippetCounters", GraalOptions.SnippetCounters),
            OptionDescriptor.create("StressExplicitExceptionCode", Boolean.class, "Stress the code emitting explicit exception throwing code.", GraalOptions.class, "StressExplicitExceptionCode", GraalOptions.StressExplicitExceptionCode),
            OptionDescriptor.create("StressInvokeWithExceptionNode", Boolean.class, "Stress the code emitting invokes with explicit exception edges.", GraalOptions.class, "StressInvokeWithExceptionNode", GraalOptions.StressInvokeWithExceptionNode),
            OptionDescriptor.create("StressTestEarlyReads", Boolean.class, "Stress the code by emitting reads at earliest instead of latest point.", GraalOptions.class, "StressTestEarlyReads", GraalOptions.StressTestEarlyReads),
            OptionDescriptor.create("SupportJsrBytecodes", Boolean.class, "", GraalOptions.class, "SupportJsrBytecodes", GraalOptions.SupportJsrBytecodes),
            OptionDescriptor.create("TailDuplicationProbability", Double.class, "", GraalOptions.class, "TailDuplicationProbability", GraalOptions.TailDuplicationProbability),
            OptionDescriptor.create("TailDuplicationTrivialSize", Integer.class, "", GraalOptions.class, "TailDuplicationTrivialSize", GraalOptions.TailDuplicationTrivialSize),
            OptionDescriptor.create("TraceEscapeAnalysis", Boolean.class, "", GraalOptions.class, "TraceEscapeAnalysis", GraalOptions.TraceEscapeAnalysis),
            OptionDescriptor.create("TraceRA", Boolean.class, "Enable experimental Trace Register Allocation.", GraalOptions.class, "TraceRA", GraalOptions.TraceRA),
            OptionDescriptor.create("TrivialInliningSize", Integer.class, "Graphs with less than this number of nodes are trivial and therefore always inlined.", GraalOptions.class, "TrivialInliningSize", GraalOptions.TrivialInliningSize),
            OptionDescriptor.create("UseExceptionProbability", Boolean.class, "", GraalOptions.class, "UseExceptionProbability", GraalOptions.UseExceptionProbability),
            OptionDescriptor.create("UseLoopLimitChecks", Boolean.class, "", GraalOptions.class, "UseLoopLimitChecks", GraalOptions.UseLoopLimitChecks),
            OptionDescriptor.create("UseSnippetGraphCache", Boolean.class, "Use a cache for snippet graphs.", GraalOptions.class, "UseSnippetGraphCache", GraalOptions.UseSnippetGraphCache),
            OptionDescriptor.create("UseTypeCheckHints", Boolean.class, "", GraalOptions.class, "UseTypeCheckHints", GraalOptions.UseTypeCheckHints),
            OptionDescriptor.create("VerifyHeapAtReturn", Boolean.class, "Perform platform dependent validation of the Java heap at returns", GraalOptions.class, "VerifyHeapAtReturn", GraalOptions.VerifyHeapAtReturn),
            OptionDescriptor.create("VerifyPhases", Boolean.class, "", GraalOptions.class, "VerifyPhases", GraalOptions.VerifyPhases),
            OptionDescriptor.create("ZapStackOnMethodEntry", Boolean.class, "", GraalOptions.class, "ZapStackOnMethodEntry", GraalOptions.ZapStackOnMethodEntry)
        );
        // CheckStyle: resume line length check
        return options.iterator();
    }
}
