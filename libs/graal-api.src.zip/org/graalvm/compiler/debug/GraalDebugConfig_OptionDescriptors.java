// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// Source: GraalDebugConfig.java
package org.graalvm.compiler.debug;

import java.util.*;
import org.graalvm.compiler.options.*;

public class GraalDebugConfig_OptionDescriptors implements OptionDescriptors {
    @Override
    public OptionDescriptor get(String value) {
        // CheckStyle: stop line length check
        if (value.equals("BootstrapInitializeOnly")) {
            return OptionDescriptor.create("BootstrapInitializeOnly", Boolean.class, "Do not compile anything on bootstrap but just initialize the compiler.", GraalDebugConfig.Options.class, "BootstrapInitializeOnly", GraalDebugConfig.Options.BootstrapInitializeOnly);
        }
        if (value.equals("CanonicalGraphStringsCheckConstants")) {
            return OptionDescriptor.create("CanonicalGraphStringsCheckConstants", Boolean.class, "Exclude virtual nodes when dumping canonical text for graphs.", GraalDebugConfig.Options.class, "CanonicalGraphStringsCheckConstants", GraalDebugConfig.Options.CanonicalGraphStringsCheckConstants);
        }
        if (value.equals("CanonicalGraphStringsExcludeVirtuals")) {
            return OptionDescriptor.create("CanonicalGraphStringsExcludeVirtuals", Boolean.class, "Exclude virtual nodes when dumping canonical text for graphs.", GraalDebugConfig.Options.class, "CanonicalGraphStringsExcludeVirtuals", GraalDebugConfig.Options.CanonicalGraphStringsExcludeVirtuals);
        }
        if (value.equals("CanonicalGraphStringsRemoveIdentities")) {
            return OptionDescriptor.create("CanonicalGraphStringsRemoveIdentities", Boolean.class, "Attempts to remove object identity hashes when dumping canonical text for graphs.", GraalDebugConfig.Options.class, "CanonicalGraphStringsRemoveIdentities", GraalDebugConfig.Options.CanonicalGraphStringsRemoveIdentities);
        }
        if (value.equals("ClearMetricsAfterBootstrap")) {
            return OptionDescriptor.create("ClearMetricsAfterBootstrap", Boolean.class, "Clear the debug metrics after bootstrap.", GraalDebugConfig.Options.class, "ClearMetricsAfterBootstrap", GraalDebugConfig.Options.ClearMetricsAfterBootstrap);
        }
        if (value.equals("Count")) {
            return OptionDescriptor.create("Count", String.class, "Pattern for scope(s) in which counting is enabled (see DebugFilter and Debug.counter). An empty value enables all counters unconditionally.", GraalDebugConfig.Options.class, "Count", GraalDebugConfig.Options.Count);
        }
        if (value.equals("DebugStubsAndSnippets")) {
            return OptionDescriptor.create("DebugStubsAndSnippets", Boolean.class, "Enable debug output for stub code generation and snippet preparation.", GraalDebugConfig.Options.class, "DebugStubsAndSnippets", GraalDebugConfig.Options.DebugStubsAndSnippets);
        }
        if (value.equals("DebugValueFile")) {
            return OptionDescriptor.create("DebugValueFile", String.class, "Write debug values into a file instead of the terminal. If DebugValueSummary is Thread, the thread name will be prepended.", GraalDebugConfig.Options.class, "DebugValueFile", GraalDebugConfig.Options.DebugValueFile);
        }
        if (value.equals("DebugValueHumanReadable")) {
            return OptionDescriptor.create("DebugValueHumanReadable", Boolean.class, "Print counters and timers in a human readable form.", GraalDebugConfig.Options.class, "DebugValueHumanReadable", GraalDebugConfig.Options.DebugValueHumanReadable);
        }
        if (value.equals("DebugValueSummary")) {
            return OptionDescriptor.create("DebugValueSummary", String.class, "How to print counters and timing values:%nName - aggregate by unqualified name%nPartial - aggregate by partially qualified name (e.g., A.B.C.D.Counter and X.Y.Z.D.Counter will be merged to D.Counter)%nComplete - aggregate by qualified name%nThread - aggregate by qualified name and thread", GraalDebugConfig.Options.class, "DebugValueSummary", GraalDebugConfig.Options.DebugValueSummary);
        }
        if (value.equals("DebugValueThreadFilter")) {
            return OptionDescriptor.create("DebugValueThreadFilter", String.class, "Only report debug values for maps which match the regular expression.", GraalDebugConfig.Options.class, "DebugValueThreadFilter", GraalDebugConfig.Options.DebugValueThreadFilter);
        }
        if (value.equals("Dump")) {
            return OptionDescriptor.create("Dump", String.class, "Pattern for scope(s) in which dumping is enabled (see DebugFilter and Debug.dump)", GraalDebugConfig.Options.class, "Dump", GraalDebugConfig.Options.Dump);
        }
        if (value.equals("DumpOnError")) {
            return OptionDescriptor.create("DumpOnError", Boolean.class, "Send Graal compiler IR to dump handlers on error.", GraalDebugConfig.Options.class, "DumpOnError", GraalDebugConfig.Options.DumpOnError);
        }
        if (value.equals("DumpOnPhaseChange")) {
            return OptionDescriptor.create("DumpOnPhaseChange", String.class, "Dump a before and after graph if the named phase changes the graph.%nThe argument is substring matched against the simple name of the phase class", GraalDebugConfig.Options.class, "DumpOnPhaseChange", GraalDebugConfig.Options.DumpOnPhaseChange);
        }
        if (value.equals("DumpPath")) {
            return OptionDescriptor.create("DumpPath", String.class, "The directory where various Graal dump files are written.", GraalDebugConfig.Options.class, "DumpPath", GraalDebugConfig.Options.DumpPath);
        }
        if (value.equals("DumpingErrorsAreFatal")) {
            return OptionDescriptor.create("DumpingErrorsAreFatal", Boolean.class, "Treat any exceptions during dumping as fatal.", GraalDebugConfig.Options.class, "DumpingErrorsAreFatal", GraalDebugConfig.Options.DumpingErrorsAreFatal);
        }
        if (value.equals("ForceDebugEnable")) {
            return OptionDescriptor.create("ForceDebugEnable", Boolean.class, "Force-enable debug code paths", GraalDebugConfig.Options.class, "ForceDebugEnable", GraalDebugConfig.Options.ForceDebugEnable);
        }
        if (value.equals("GlobalMetricsInterceptedByMethodMetrics")) {
            return OptionDescriptor.create("GlobalMetricsInterceptedByMethodMetrics", String.class, "If a global metric (DebugTimer, DebugCounter or DebugMemUseTracker) is enabled in the same scope as a method metric, use the global metric to update the method metric for the current compilation. This option enables the re-use of global metrics on per-compilation basis. Whenever a value is added to a global metric, the value is also added to a MethodMetric under the same name as the global metric. This option incurs a small but constant overhead due to the context method lookup at each metric update. Format to specify GlobalMetric interception:(Timers|Counters|MemUseTrackers)(,Timers|,Counters|,MemUseTrackers)*", GraalDebugConfig.Options.class, "GlobalMetricsInterceptedByMethodMetrics", GraalDebugConfig.Options.GlobalMetricsInterceptedByMethodMetrics);
        }
        if (value.equals("InterceptBailout")) {
            return OptionDescriptor.create("InterceptBailout", Boolean.class, "Intercept also bailout exceptions", GraalDebugConfig.Options.class, "InterceptBailout", GraalDebugConfig.Options.InterceptBailout);
        }
        if (value.equals("Log")) {
            return OptionDescriptor.create("Log", String.class, "Pattern for scope(s) in which logging is enabled (see DebugFilter and Debug.log)", GraalDebugConfig.Options.class, "Log", GraalDebugConfig.Options.Log);
        }
        if (value.equals("LogVerbose")) {
            return OptionDescriptor.create("LogVerbose", Boolean.class, "Enable more verbose log output when available", GraalDebugConfig.Options.class, "LogVerbose", GraalDebugConfig.Options.LogVerbose);
        }
        if (value.equals("MethodFilter")) {
            return OptionDescriptor.create("MethodFilter", String.class, "Pattern for filtering debug scope output based on method context (see MethodFilter)", GraalDebugConfig.Options.class, "MethodFilter", GraalDebugConfig.Options.MethodFilter);
        }
        if (value.equals("MethodFilterRootOnly")) {
            return OptionDescriptor.create("MethodFilterRootOnly", Boolean.class, "Only check MethodFilter against the root method in the context if true, otherwise check all methods", GraalDebugConfig.Options.class, "MethodFilterRootOnly", GraalDebugConfig.Options.MethodFilterRootOnly);
        }
        if (value.equals("MethodMeter")) {
            return OptionDescriptor.create("MethodMeter", String.class, "Enable per method metrics that are collected across all compilations of a method.Pattern for scope(s) in which method metering is enabled (see DebugFilter and Debug.metric).", GraalDebugConfig.Options.class, "MethodMeter", GraalDebugConfig.Options.MethodMeter);
        }
        if (value.equals("PrintBackendCFG")) {
            return OptionDescriptor.create("PrintBackendCFG", Boolean.class, "Enable dumping LIR, register allocation and code generation info to the C1Visualizer.", GraalDebugConfig.Options.class, "PrintBackendCFG", GraalDebugConfig.Options.PrintBackendCFG);
        }
        if (value.equals("PrintBinaryGraphPort")) {
            return OptionDescriptor.create("PrintBinaryGraphPort", Integer.class, "Port part of the address to which graphs are dumped in binary format (ignored if PrintBinaryGraphs=false).", GraalDebugConfig.Options.class, "PrintBinaryGraphPort", GraalDebugConfig.Options.PrintBinaryGraphPort);
        }
        if (value.equals("PrintBinaryGraphs")) {
            return OptionDescriptor.create("PrintBinaryGraphs", Boolean.class, "Dump graphs in binary format instead of XML format.", GraalDebugConfig.Options.class, "PrintBinaryGraphs", GraalDebugConfig.Options.PrintBinaryGraphs);
        }
        if (value.equals("PrintCFG")) {
            return OptionDescriptor.create("PrintCFG", Boolean.class, "Enable dumping to the C1Visualizer. Enabling this option implies PrintBackendCFG.", GraalDebugConfig.Options.class, "PrintCFG", GraalDebugConfig.Options.PrintCFG);
        }
        if (value.equals("PrintCFGFileName")) {
            return OptionDescriptor.create("PrintCFGFileName", String.class, "Base filename when dumping C1Visualizer output to files.", GraalDebugConfig.Options.class, "PrintCFGFileName", GraalDebugConfig.Options.PrintCFGFileName);
        }
        if (value.equals("PrintCanonicalGraphStringFlavor")) {
            return OptionDescriptor.create("PrintCanonicalGraphStringFlavor", Integer.class, "Choose format used when dumping canonical text for graphs: 0 gives a scheduled graph (better for spotting changes involving the schedule)while 1 gives a CFG containing expressions rooted at fixed nodes (better for spotting small structure differences)", GraalDebugConfig.Options.class, "PrintCanonicalGraphStringFlavor", GraalDebugConfig.Options.PrintCanonicalGraphStringFlavor);
        }
        if (value.equals("PrintCanonicalGraphStrings")) {
            return OptionDescriptor.create("PrintCanonicalGraphStrings", Boolean.class, "Enable dumping canonical text from for graphs.", GraalDebugConfig.Options.class, "PrintCanonicalGraphStrings", GraalDebugConfig.Options.PrintCanonicalGraphStrings);
        }
        if (value.equals("PrintCanonicalGraphStringsDirectory")) {
            return OptionDescriptor.create("PrintCanonicalGraphStringsDirectory", String.class, "Base directory when dumping graphs strings to files.", GraalDebugConfig.Options.class, "PrintCanonicalGraphStringsDirectory", GraalDebugConfig.Options.PrintCanonicalGraphStringsDirectory);
        }
        if (value.equals("PrintGraph")) {
            return OptionDescriptor.create("PrintGraph", Boolean.class, "Enable dumping to the IdealGraphVisualizer.", GraalDebugConfig.Options.class, "PrintGraph", GraalDebugConfig.Options.PrintGraph);
        }
        if (value.equals("PrintGraphFile")) {
            return OptionDescriptor.create("PrintGraphFile", Boolean.class, "Print graphs to files instead of sending them over the network.", GraalDebugConfig.Options.class, "PrintGraphFile", GraalDebugConfig.Options.PrintGraphFile);
        }
        if (value.equals("PrintGraphFileName")) {
            return OptionDescriptor.create("PrintGraphFileName", String.class, "Base filename when dumping graphs to files.", GraalDebugConfig.Options.class, "PrintGraphFileName", GraalDebugConfig.Options.PrintGraphFileName);
        }
        if (value.equals("PrintGraphHost")) {
            return OptionDescriptor.create("PrintGraphHost", String.class, "Host part of the address to which graphs are dumped.", GraalDebugConfig.Options.class, "PrintGraphHost", GraalDebugConfig.Options.PrintGraphHost);
        }
        if (value.equals("PrintGraphProbabilities")) {
            return OptionDescriptor.create("PrintGraphProbabilities", Boolean.class, "Output probabilities for fixed nodes during binary graph dumping.", GraalDebugConfig.Options.class, "PrintGraphProbabilities", GraalDebugConfig.Options.PrintGraphProbabilities);
        }
        if (value.equals("PrintGraphWithSchedule")) {
            return OptionDescriptor.create("PrintGraphWithSchedule", Boolean.class, "Schedule graphs as they are dumped.", GraalDebugConfig.Options.class, "PrintGraphWithSchedule", GraalDebugConfig.Options.PrintGraphWithSchedule);
        }
        if (value.equals("PrintIdealGraph")) {
            return OptionDescriptor.create("PrintIdealGraph", Boolean.class, "Deprecated - use PrintGraph instead.", GraalDebugConfig.Options.class, "PrintIdealGraph", GraalDebugConfig.Options.PrintIdealGraph);
        }
        if (value.equals("PrintIdealGraphAddress")) {
            return OptionDescriptor.create("PrintIdealGraphAddress", String.class, "Deprecated - use PrintGraphHost instead.", GraalDebugConfig.Options.class, "PrintIdealGraphAddress", GraalDebugConfig.Options.PrintIdealGraphAddress);
        }
        if (value.equals("PrintIdealGraphFile")) {
            return OptionDescriptor.create("PrintIdealGraphFile", Boolean.class, "Deprecated - use PrintGraphFile instead.", GraalDebugConfig.Options.class, "PrintIdealGraphFile", GraalDebugConfig.Options.PrintIdealGraphFile);
        }
        if (value.equals("PrintIdealGraphFileName")) {
            return OptionDescriptor.create("PrintIdealGraphFileName", String.class, "Deprecated - use PrintGraphFileName instead.", GraalDebugConfig.Options.class, "PrintIdealGraphFileName", GraalDebugConfig.Options.PrintIdealGraphFileName);
        }
        if (value.equals("PrintIdealGraphPort")) {
            return OptionDescriptor.create("PrintIdealGraphPort", Integer.class, "Deprecated - use PrintXmlGraphPort instead.", GraalDebugConfig.Options.class, "PrintIdealGraphPort", GraalDebugConfig.Options.PrintIdealGraphPort);
        }
        if (value.equals("PrintIdealGraphSchedule")) {
            return OptionDescriptor.create("PrintIdealGraphSchedule", Boolean.class, "Deprecated - use PrintGraphWithSchedule instead.", GraalDebugConfig.Options.class, "PrintIdealGraphSchedule", GraalDebugConfig.Options.PrintIdealGraphSchedule);
        }
        if (value.equals("PrintTruffleTrees")) {
            return OptionDescriptor.create("PrintTruffleTrees", Boolean.class, "Enable dumping Truffle ASTs to the IdealGraphVisualizer.", GraalDebugConfig.Options.class, "PrintTruffleTrees", GraalDebugConfig.Options.PrintTruffleTrees);
        }
        if (value.equals("PrintXmlGraphPort")) {
            return OptionDescriptor.create("PrintXmlGraphPort", Integer.class, "Port part of the address to which graphs are dumped in XML format (ignored if PrintBinaryGraphs=true).", GraalDebugConfig.Options.class, "PrintXmlGraphPort", GraalDebugConfig.Options.PrintXmlGraphPort);
        }
        if (value.equals("SuppressZeroDebugValues")) {
            return OptionDescriptor.create("SuppressZeroDebugValues", Boolean.class, "Omit reporting 0-value counters", GraalDebugConfig.Options.class, "SuppressZeroDebugValues", GraalDebugConfig.Options.SuppressZeroDebugValues);
        }
        if (value.equals("Time")) {
            return OptionDescriptor.create("Time", String.class, "Pattern for scope(s) in which timing is enabled (see DebugFilter and Debug.timer). An empty value enables all timers unconditionally.", GraalDebugConfig.Options.class, "Time", GraalDebugConfig.Options.Time);
        }
        if (value.equals("TrackMemUse")) {
            return OptionDescriptor.create("TrackMemUse", String.class, "Pattern for scope(s) in which memory use tracking is enabled (see DebugFilter and Debug.counter). An empty value enables all memory use trackers unconditionally.", GraalDebugConfig.Options.class, "TrackMemUse", GraalDebugConfig.Options.TrackMemUse);
        }
        if (value.equals("Verify")) {
            return OptionDescriptor.create("Verify", String.class, "Pattern for scope(s) in which verification is enabled (see DebugFilter and Debug.verify).", GraalDebugConfig.Options.class, "Verify", GraalDebugConfig.Options.Verify);
        }
        // CheckStyle: resume line length check
        return null;
    }

    @Override
    public Iterator<OptionDescriptor> iterator() {
        // CheckStyle: stop line length check
        List<OptionDescriptor> options = Arrays.asList(
            OptionDescriptor.create("BootstrapInitializeOnly", Boolean.class, "Do not compile anything on bootstrap but just initialize the compiler.", GraalDebugConfig.Options.class, "BootstrapInitializeOnly", GraalDebugConfig.Options.BootstrapInitializeOnly),
            OptionDescriptor.create("CanonicalGraphStringsCheckConstants", Boolean.class, "Exclude virtual nodes when dumping canonical text for graphs.", GraalDebugConfig.Options.class, "CanonicalGraphStringsCheckConstants", GraalDebugConfig.Options.CanonicalGraphStringsCheckConstants),
            OptionDescriptor.create("CanonicalGraphStringsExcludeVirtuals", Boolean.class, "Exclude virtual nodes when dumping canonical text for graphs.", GraalDebugConfig.Options.class, "CanonicalGraphStringsExcludeVirtuals", GraalDebugConfig.Options.CanonicalGraphStringsExcludeVirtuals),
            OptionDescriptor.create("CanonicalGraphStringsRemoveIdentities", Boolean.class, "Attempts to remove object identity hashes when dumping canonical text for graphs.", GraalDebugConfig.Options.class, "CanonicalGraphStringsRemoveIdentities", GraalDebugConfig.Options.CanonicalGraphStringsRemoveIdentities),
            OptionDescriptor.create("ClearMetricsAfterBootstrap", Boolean.class, "Clear the debug metrics after bootstrap.", GraalDebugConfig.Options.class, "ClearMetricsAfterBootstrap", GraalDebugConfig.Options.ClearMetricsAfterBootstrap),
            OptionDescriptor.create("Count", String.class, "Pattern for scope(s) in which counting is enabled (see DebugFilter and Debug.counter). An empty value enables all counters unconditionally.", GraalDebugConfig.Options.class, "Count", GraalDebugConfig.Options.Count),
            OptionDescriptor.create("DebugStubsAndSnippets", Boolean.class, "Enable debug output for stub code generation and snippet preparation.", GraalDebugConfig.Options.class, "DebugStubsAndSnippets", GraalDebugConfig.Options.DebugStubsAndSnippets),
            OptionDescriptor.create("DebugValueFile", String.class, "Write debug values into a file instead of the terminal. If DebugValueSummary is Thread, the thread name will be prepended.", GraalDebugConfig.Options.class, "DebugValueFile", GraalDebugConfig.Options.DebugValueFile),
            OptionDescriptor.create("DebugValueHumanReadable", Boolean.class, "Print counters and timers in a human readable form.", GraalDebugConfig.Options.class, "DebugValueHumanReadable", GraalDebugConfig.Options.DebugValueHumanReadable),
            OptionDescriptor.create("DebugValueSummary", String.class, "How to print counters and timing values:%nName - aggregate by unqualified name%nPartial - aggregate by partially qualified name (e.g., A.B.C.D.Counter and X.Y.Z.D.Counter will be merged to D.Counter)%nComplete - aggregate by qualified name%nThread - aggregate by qualified name and thread", GraalDebugConfig.Options.class, "DebugValueSummary", GraalDebugConfig.Options.DebugValueSummary),
            OptionDescriptor.create("DebugValueThreadFilter", String.class, "Only report debug values for maps which match the regular expression.", GraalDebugConfig.Options.class, "DebugValueThreadFilter", GraalDebugConfig.Options.DebugValueThreadFilter),
            OptionDescriptor.create("Dump", String.class, "Pattern for scope(s) in which dumping is enabled (see DebugFilter and Debug.dump)", GraalDebugConfig.Options.class, "Dump", GraalDebugConfig.Options.Dump),
            OptionDescriptor.create("DumpOnError", Boolean.class, "Send Graal compiler IR to dump handlers on error.", GraalDebugConfig.Options.class, "DumpOnError", GraalDebugConfig.Options.DumpOnError),
            OptionDescriptor.create("DumpOnPhaseChange", String.class, "Dump a before and after graph if the named phase changes the graph.%nThe argument is substring matched against the simple name of the phase class", GraalDebugConfig.Options.class, "DumpOnPhaseChange", GraalDebugConfig.Options.DumpOnPhaseChange),
            OptionDescriptor.create("DumpPath", String.class, "The directory where various Graal dump files are written.", GraalDebugConfig.Options.class, "DumpPath", GraalDebugConfig.Options.DumpPath),
            OptionDescriptor.create("DumpingErrorsAreFatal", Boolean.class, "Treat any exceptions during dumping as fatal.", GraalDebugConfig.Options.class, "DumpingErrorsAreFatal", GraalDebugConfig.Options.DumpingErrorsAreFatal),
            OptionDescriptor.create("ForceDebugEnable", Boolean.class, "Force-enable debug code paths", GraalDebugConfig.Options.class, "ForceDebugEnable", GraalDebugConfig.Options.ForceDebugEnable),
            OptionDescriptor.create("GlobalMetricsInterceptedByMethodMetrics", String.class, "If a global metric (DebugTimer, DebugCounter or DebugMemUseTracker) is enabled in the same scope as a method metric, use the global metric to update the method metric for the current compilation. This option enables the re-use of global metrics on per-compilation basis. Whenever a value is added to a global metric, the value is also added to a MethodMetric under the same name as the global metric. This option incurs a small but constant overhead due to the context method lookup at each metric update. Format to specify GlobalMetric interception:(Timers|Counters|MemUseTrackers)(,Timers|,Counters|,MemUseTrackers)*", GraalDebugConfig.Options.class, "GlobalMetricsInterceptedByMethodMetrics", GraalDebugConfig.Options.GlobalMetricsInterceptedByMethodMetrics),
            OptionDescriptor.create("InterceptBailout", Boolean.class, "Intercept also bailout exceptions", GraalDebugConfig.Options.class, "InterceptBailout", GraalDebugConfig.Options.InterceptBailout),
            OptionDescriptor.create("Log", String.class, "Pattern for scope(s) in which logging is enabled (see DebugFilter and Debug.log)", GraalDebugConfig.Options.class, "Log", GraalDebugConfig.Options.Log),
            OptionDescriptor.create("LogVerbose", Boolean.class, "Enable more verbose log output when available", GraalDebugConfig.Options.class, "LogVerbose", GraalDebugConfig.Options.LogVerbose),
            OptionDescriptor.create("MethodFilter", String.class, "Pattern for filtering debug scope output based on method context (see MethodFilter)", GraalDebugConfig.Options.class, "MethodFilter", GraalDebugConfig.Options.MethodFilter),
            OptionDescriptor.create("MethodFilterRootOnly", Boolean.class, "Only check MethodFilter against the root method in the context if true, otherwise check all methods", GraalDebugConfig.Options.class, "MethodFilterRootOnly", GraalDebugConfig.Options.MethodFilterRootOnly),
            OptionDescriptor.create("MethodMeter", String.class, "Enable per method metrics that are collected across all compilations of a method.Pattern for scope(s) in which method metering is enabled (see DebugFilter and Debug.metric).", GraalDebugConfig.Options.class, "MethodMeter", GraalDebugConfig.Options.MethodMeter),
            OptionDescriptor.create("PrintBackendCFG", Boolean.class, "Enable dumping LIR, register allocation and code generation info to the C1Visualizer.", GraalDebugConfig.Options.class, "PrintBackendCFG", GraalDebugConfig.Options.PrintBackendCFG),
            OptionDescriptor.create("PrintBinaryGraphPort", Integer.class, "Port part of the address to which graphs are dumped in binary format (ignored if PrintBinaryGraphs=false).", GraalDebugConfig.Options.class, "PrintBinaryGraphPort", GraalDebugConfig.Options.PrintBinaryGraphPort),
            OptionDescriptor.create("PrintBinaryGraphs", Boolean.class, "Dump graphs in binary format instead of XML format.", GraalDebugConfig.Options.class, "PrintBinaryGraphs", GraalDebugConfig.Options.PrintBinaryGraphs),
            OptionDescriptor.create("PrintCFG", Boolean.class, "Enable dumping to the C1Visualizer. Enabling this option implies PrintBackendCFG.", GraalDebugConfig.Options.class, "PrintCFG", GraalDebugConfig.Options.PrintCFG),
            OptionDescriptor.create("PrintCFGFileName", String.class, "Base filename when dumping C1Visualizer output to files.", GraalDebugConfig.Options.class, "PrintCFGFileName", GraalDebugConfig.Options.PrintCFGFileName),
            OptionDescriptor.create("PrintCanonicalGraphStringFlavor", Integer.class, "Choose format used when dumping canonical text for graphs: 0 gives a scheduled graph (better for spotting changes involving the schedule)while 1 gives a CFG containing expressions rooted at fixed nodes (better for spotting small structure differences)", GraalDebugConfig.Options.class, "PrintCanonicalGraphStringFlavor", GraalDebugConfig.Options.PrintCanonicalGraphStringFlavor),
            OptionDescriptor.create("PrintCanonicalGraphStrings", Boolean.class, "Enable dumping canonical text from for graphs.", GraalDebugConfig.Options.class, "PrintCanonicalGraphStrings", GraalDebugConfig.Options.PrintCanonicalGraphStrings),
            OptionDescriptor.create("PrintCanonicalGraphStringsDirectory", String.class, "Base directory when dumping graphs strings to files.", GraalDebugConfig.Options.class, "PrintCanonicalGraphStringsDirectory", GraalDebugConfig.Options.PrintCanonicalGraphStringsDirectory),
            OptionDescriptor.create("PrintGraph", Boolean.class, "Enable dumping to the IdealGraphVisualizer.", GraalDebugConfig.Options.class, "PrintGraph", GraalDebugConfig.Options.PrintGraph),
            OptionDescriptor.create("PrintGraphFile", Boolean.class, "Print graphs to files instead of sending them over the network.", GraalDebugConfig.Options.class, "PrintGraphFile", GraalDebugConfig.Options.PrintGraphFile),
            OptionDescriptor.create("PrintGraphFileName", String.class, "Base filename when dumping graphs to files.", GraalDebugConfig.Options.class, "PrintGraphFileName", GraalDebugConfig.Options.PrintGraphFileName),
            OptionDescriptor.create("PrintGraphHost", String.class, "Host part of the address to which graphs are dumped.", GraalDebugConfig.Options.class, "PrintGraphHost", GraalDebugConfig.Options.PrintGraphHost),
            OptionDescriptor.create("PrintGraphProbabilities", Boolean.class, "Output probabilities for fixed nodes during binary graph dumping.", GraalDebugConfig.Options.class, "PrintGraphProbabilities", GraalDebugConfig.Options.PrintGraphProbabilities),
            OptionDescriptor.create("PrintGraphWithSchedule", Boolean.class, "Schedule graphs as they are dumped.", GraalDebugConfig.Options.class, "PrintGraphWithSchedule", GraalDebugConfig.Options.PrintGraphWithSchedule),
            OptionDescriptor.create("PrintIdealGraph", Boolean.class, "Deprecated - use PrintGraph instead.", GraalDebugConfig.Options.class, "PrintIdealGraph", GraalDebugConfig.Options.PrintIdealGraph),
            OptionDescriptor.create("PrintIdealGraphAddress", String.class, "Deprecated - use PrintGraphHost instead.", GraalDebugConfig.Options.class, "PrintIdealGraphAddress", GraalDebugConfig.Options.PrintIdealGraphAddress),
            OptionDescriptor.create("PrintIdealGraphFile", Boolean.class, "Deprecated - use PrintGraphFile instead.", GraalDebugConfig.Options.class, "PrintIdealGraphFile", GraalDebugConfig.Options.PrintIdealGraphFile),
            OptionDescriptor.create("PrintIdealGraphFileName", String.class, "Deprecated - use PrintGraphFileName instead.", GraalDebugConfig.Options.class, "PrintIdealGraphFileName", GraalDebugConfig.Options.PrintIdealGraphFileName),
            OptionDescriptor.create("PrintIdealGraphPort", Integer.class, "Deprecated - use PrintXmlGraphPort instead.", GraalDebugConfig.Options.class, "PrintIdealGraphPort", GraalDebugConfig.Options.PrintIdealGraphPort),
            OptionDescriptor.create("PrintIdealGraphSchedule", Boolean.class, "Deprecated - use PrintGraphWithSchedule instead.", GraalDebugConfig.Options.class, "PrintIdealGraphSchedule", GraalDebugConfig.Options.PrintIdealGraphSchedule),
            OptionDescriptor.create("PrintTruffleTrees", Boolean.class, "Enable dumping Truffle ASTs to the IdealGraphVisualizer.", GraalDebugConfig.Options.class, "PrintTruffleTrees", GraalDebugConfig.Options.PrintTruffleTrees),
            OptionDescriptor.create("PrintXmlGraphPort", Integer.class, "Port part of the address to which graphs are dumped in XML format (ignored if PrintBinaryGraphs=true).", GraalDebugConfig.Options.class, "PrintXmlGraphPort", GraalDebugConfig.Options.PrintXmlGraphPort),
            OptionDescriptor.create("SuppressZeroDebugValues", Boolean.class, "Omit reporting 0-value counters", GraalDebugConfig.Options.class, "SuppressZeroDebugValues", GraalDebugConfig.Options.SuppressZeroDebugValues),
            OptionDescriptor.create("Time", String.class, "Pattern for scope(s) in which timing is enabled (see DebugFilter and Debug.timer). An empty value enables all timers unconditionally.", GraalDebugConfig.Options.class, "Time", GraalDebugConfig.Options.Time),
            OptionDescriptor.create("TrackMemUse", String.class, "Pattern for scope(s) in which memory use tracking is enabled (see DebugFilter and Debug.counter). An empty value enables all memory use trackers unconditionally.", GraalDebugConfig.Options.class, "TrackMemUse", GraalDebugConfig.Options.TrackMemUse),
            OptionDescriptor.create("Verify", String.class, "Pattern for scope(s) in which verification is enabled (see DebugFilter and Debug.verify).", GraalDebugConfig.Options.class, "Verify", GraalDebugConfig.Options.Verify)
        );
        // CheckStyle: resume line length check
        return options.iterator();
    }
}
