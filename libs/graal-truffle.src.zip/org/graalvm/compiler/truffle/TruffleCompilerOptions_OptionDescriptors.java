// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// Source: TruffleCompilerOptions.java
package org.graalvm.compiler.truffle;

import java.util.*;
import org.graalvm.compiler.options.*;

public class TruffleCompilerOptions_OptionDescriptors implements OptionDescriptors {
    @Override
    public OptionDescriptor get(String value) {
        // CheckStyle: stop line length check
        if (value.equals("PrintTruffleExpansionHistogram")) {
            return OptionDescriptor.create("PrintTruffleExpansionHistogram", Boolean.class, "Prints a histogram of all expanded Java methods.", TruffleCompilerOptions.class, "PrintTruffleExpansionHistogram", TruffleCompilerOptions.PrintTruffleExpansionHistogram);
        }
        if (value.equals("TraceTruffleAssumptions")) {
            return OptionDescriptor.create("TraceTruffleAssumptions", Boolean.class, "Print stack trace on assumption invalidation", TruffleCompilerOptions.class, "TraceTruffleAssumptions", TruffleCompilerOptions.TraceTruffleAssumptions);
        }
        if (value.equals("TraceTruffleCompilation")) {
            return OptionDescriptor.create("TraceTruffleCompilation", Boolean.class, "Print information for compilation results", TruffleCompilerOptions.class, "TraceTruffleCompilation", TruffleCompilerOptions.TraceTruffleCompilation);
        }
        if (value.equals("TraceTruffleCompilationAST")) {
            return OptionDescriptor.create("TraceTruffleCompilationAST", Boolean.class, "Print all polymorphic and generic nodes after each compilation", TruffleCompilerOptions.class, "TraceTruffleCompilationAST", TruffleCompilerOptions.TraceTruffleCompilationAST);
        }
        if (value.equals("TraceTruffleCompilationCallTree")) {
            return OptionDescriptor.create("TraceTruffleCompilationCallTree", Boolean.class, "Print the inlined call tree for each compiled method", TruffleCompilerOptions.class, "TraceTruffleCompilationCallTree", TruffleCompilerOptions.TraceTruffleCompilationCallTree);
        }
        if (value.equals("TraceTruffleCompilationDetails")) {
            return OptionDescriptor.create("TraceTruffleCompilationDetails", Boolean.class, "Print information for compilation queuing", TruffleCompilerOptions.class, "TraceTruffleCompilationDetails", TruffleCompilerOptions.TraceTruffleCompilationDetails);
        }
        if (value.equals("TraceTruffleCompilationPolymorphism")) {
            return OptionDescriptor.create("TraceTruffleCompilationPolymorphism", Boolean.class, "Print all polymorphic and generic nodes after each compilation", TruffleCompilerOptions.class, "TraceTruffleCompilationPolymorphism", TruffleCompilerOptions.TraceTruffleCompilationPolymorphism);
        }
        if (value.equals("TraceTruffleExpansionSource")) {
            return OptionDescriptor.create("TraceTruffleExpansionSource", Boolean.class, "Print source secions for printed expansion trees", TruffleCompilerOptions.class, "TraceTruffleExpansionSource", TruffleCompilerOptions.TraceTruffleExpansionSource);
        }
        if (value.equals("TraceTruffleInlining")) {
            return OptionDescriptor.create("TraceTruffleInlining", Boolean.class, "Print information for inlining for each compilation.", TruffleCompilerOptions.class, "TraceTruffleInlining", TruffleCompilerOptions.TraceTruffleInlining);
        }
        if (value.equals("TraceTrufflePerformanceWarnings")) {
            return OptionDescriptor.create("TraceTrufflePerformanceWarnings", Boolean.class, "Print potential performance problems", TruffleCompilerOptions.class, "TraceTrufflePerformanceWarnings", TruffleCompilerOptions.TraceTrufflePerformanceWarnings);
        }
        if (value.equals("TraceTruffleSplitting")) {
            return OptionDescriptor.create("TraceTruffleSplitting", Boolean.class, "Print information for each splitted call site.", TruffleCompilerOptions.class, "TraceTruffleSplitting", TruffleCompilerOptions.TraceTruffleSplitting);
        }
        if (value.equals("TraceTruffleStackTraceLimit")) {
            return OptionDescriptor.create("TraceTruffleStackTraceLimit", Integer.class, "Number of stack trace elements printed by TraceTruffleTransferToInterpreter and TraceTruffleAssumptions", TruffleCompilerOptions.class, "TraceTruffleStackTraceLimit", TruffleCompilerOptions.TraceTruffleStackTraceLimit);
        }
        if (value.equals("TraceTruffleTransferToInterpreter")) {
            return OptionDescriptor.create("TraceTruffleTransferToInterpreter", Boolean.class, "Print stack trace on transfer to interpreter", TruffleCompilerOptions.class, "TraceTruffleTransferToInterpreter", TruffleCompilerOptions.TraceTruffleTransferToInterpreter);
        }
        if (value.equals("TruffleArgumentTypeSpeculation")) {
            return OptionDescriptor.create("TruffleArgumentTypeSpeculation", Boolean.class, "", TruffleCompilerOptions.class, "TruffleArgumentTypeSpeculation", TruffleCompilerOptions.TruffleArgumentTypeSpeculation);
        }
        if (value.equals("TruffleBackgroundCompilation")) {
            return OptionDescriptor.create("TruffleBackgroundCompilation", Boolean.class, "Enable asynchronous truffle compilation in background thread", TruffleCompilerOptions.class, "TruffleBackgroundCompilation", TruffleCompilerOptions.TruffleBackgroundCompilation);
        }
        if (value.equals("TruffleCallTargetProfiling")) {
            return OptionDescriptor.create("TruffleCallTargetProfiling", Boolean.class, "Print a summary of execution counts for all executed CallTargets. Introduces counter overhead for each call.", TruffleCompilerOptions.class, "TruffleCallTargetProfiling", TruffleCompilerOptions.TruffleCallTargetProfiling);
        }
        if (value.equals("TruffleCompilationExceptionsAreFatal")) {
            return OptionDescriptor.create("TruffleCompilationExceptionsAreFatal", Boolean.class, "Treat compilation exceptions as fatal exceptions that will exit the application", TruffleCompilerOptions.class, "TruffleCompilationExceptionsAreFatal", TruffleCompilerOptions.TruffleCompilationExceptionsAreFatal);
        }
        if (value.equals("TruffleCompilationExceptionsArePrinted")) {
            return OptionDescriptor.create("TruffleCompilationExceptionsArePrinted", Boolean.class, "Prints the exception stack trace for compilation exceptions", TruffleCompilerOptions.class, "TruffleCompilationExceptionsArePrinted", TruffleCompilerOptions.TruffleCompilationExceptionsArePrinted);
        }
        if (value.equals("TruffleCompilationExceptionsAreThrown")) {
            return OptionDescriptor.create("TruffleCompilationExceptionsAreThrown", Boolean.class, "Treat compilation exceptions as thrown runtime exceptions", TruffleCompilerOptions.class, "TruffleCompilationExceptionsAreThrown", TruffleCompilerOptions.TruffleCompilationExceptionsAreThrown);
        }
        if (value.equals("TruffleCompilationRepeats")) {
            return OptionDescriptor.create("TruffleCompilationRepeats", Integer.class, "Compile time benchmarking: repeat Truffle compilation n times and then exit the VM", TruffleCompilerOptions.class, "TruffleCompilationRepeats", TruffleCompilerOptions.TruffleCompilationRepeats);
        }
        if (value.equals("TruffleCompilationStatisticDetails")) {
            return OptionDescriptor.create("TruffleCompilationStatisticDetails", Boolean.class, "Print additional more verbose Truffle compilation statistics at the end of a run.", TruffleCompilerOptions.class, "TruffleCompilationStatisticDetails", TruffleCompilerOptions.TruffleCompilationStatisticDetails);
        }
        if (value.equals("TruffleCompilationStatistics")) {
            return OptionDescriptor.create("TruffleCompilationStatistics", Boolean.class, "Print Truffle compilation statistics at the end of a run.", TruffleCompilerOptions.class, "TruffleCompilationStatistics", TruffleCompilerOptions.TruffleCompilationStatistics);
        }
        if (value.equals("TruffleCompilationThreshold")) {
            return OptionDescriptor.create("TruffleCompilationThreshold", Integer.class, "Compile call target when call count exceeds this threshold", TruffleCompilerOptions.class, "TruffleCompilationThreshold", TruffleCompilerOptions.TruffleCompilationThreshold);
        }
        if (value.equals("TruffleCompileImmediately")) {
            return OptionDescriptor.create("TruffleCompileImmediately", Boolean.class, "Compile immediately to test truffle compiler", TruffleCompilerOptions.class, "TruffleCompileImmediately", TruffleCompilerOptions.TruffleCompileImmediately);
        }
        if (value.equals("TruffleCompileOnly")) {
            return OptionDescriptor.create("TruffleCompileOnly", String.class, "Restrict compilation to comma-separated list of includes (or excludes prefixed with tilde)", TruffleCompilerOptions.class, "TruffleCompileOnly", TruffleCompilerOptions.TruffleCompileOnly);
        }
        if (value.equals("TruffleCompilerThreads")) {
            return OptionDescriptor.create("TruffleCompilerThreads", Integer.class, "Manually set the number of compiler threads", TruffleCompilerOptions.class, "TruffleCompilerThreads", TruffleCompilerOptions.TruffleCompilerThreads);
        }
        if (value.equals("TruffleEnableInfopoints")) {
            return OptionDescriptor.create("TruffleEnableInfopoints", Boolean.class, "Enable support for simple infopoints in truffle partial evaluations.", TruffleCompilerOptions.class, "TruffleEnableInfopoints", TruffleCompilerOptions.TruffleEnableInfopoints);
        }
        if (value.equals("TruffleExcludeAssertions")) {
            return OptionDescriptor.create("TruffleExcludeAssertions", Boolean.class, "Exclude assertion code from Truffle compilations", TruffleCompilerOptions.class, "TruffleExcludeAssertions", TruffleCompilerOptions.TruffleExcludeAssertions);
        }
        if (value.equals("TruffleFunctionInlining")) {
            return OptionDescriptor.create("TruffleFunctionInlining", Boolean.class, "Enable automatic inlining of call targets", TruffleCompilerOptions.class, "TruffleFunctionInlining", TruffleCompilerOptions.TruffleFunctionInlining);
        }
        if (value.equals("TruffleInlineAcrossTruffleBoundary")) {
            return OptionDescriptor.create("TruffleInlineAcrossTruffleBoundary", Boolean.class, "Enable inlining across Truffle boundary", TruffleCompilerOptions.class, "TruffleInlineAcrossTruffleBoundary", TruffleCompilerOptions.TruffleInlineAcrossTruffleBoundary);
        }
        if (value.equals("TruffleInliningMaxCallerSize")) {
            return OptionDescriptor.create("TruffleInliningMaxCallerSize", Integer.class, "Stop inlining if caller's cumulative tree size would exceed this limit", TruffleCompilerOptions.class, "TruffleInliningMaxCallerSize", TruffleCompilerOptions.TruffleInliningMaxCallerSize);
        }
        if (value.equals("TruffleInstrumentBoundaries")) {
            return OptionDescriptor.create("TruffleInstrumentBoundaries", Boolean.class, "Instrument Truffle boundaries and output profiling information to the standard output.", TruffleCompilerOptions.class, "TruffleInstrumentBoundaries", TruffleCompilerOptions.TruffleInstrumentBoundaries);
        }
        if (value.equals("TruffleInstrumentBoundariesPerInlineSite")) {
            return OptionDescriptor.create("TruffleInstrumentBoundariesPerInlineSite", Boolean.class, "Instrument Truffle boundaries by considering different inlining sites as different branches.", TruffleCompilerOptions.class, "TruffleInstrumentBoundariesPerInlineSite", TruffleCompilerOptions.TruffleInstrumentBoundariesPerInlineSite);
        }
        if (value.equals("TruffleInstrumentBranches")) {
            return OptionDescriptor.create("TruffleInstrumentBranches", Boolean.class, "Instrument branches and output profiling information to the standard output.", TruffleCompilerOptions.class, "TruffleInstrumentBranches", TruffleCompilerOptions.TruffleInstrumentBranches);
        }
        if (value.equals("TruffleInstrumentBranchesCount")) {
            return OptionDescriptor.create("TruffleInstrumentBranchesCount", Integer.class, "Maximum number of instrumentation counters available.", TruffleCompilerOptions.class, "TruffleInstrumentBranchesCount", TruffleCompilerOptions.TruffleInstrumentBranchesCount);
        }
        if (value.equals("TruffleInstrumentBranchesFilter")) {
            return OptionDescriptor.create("TruffleInstrumentBranchesFilter", String.class, "Method filter for methods in which to add branch instrumentation.", TruffleCompilerOptions.class, "TruffleInstrumentBranchesFilter", TruffleCompilerOptions.TruffleInstrumentBranchesFilter);
        }
        if (value.equals("TruffleInstrumentBranchesPerInlineSite")) {
            return OptionDescriptor.create("TruffleInstrumentBranchesPerInlineSite", Boolean.class, "Instrument branches by considering different inlining sites as different branches.", TruffleCompilerOptions.class, "TruffleInstrumentBranchesPerInlineSite", TruffleCompilerOptions.TruffleInstrumentBranchesPerInlineSite);
        }
        if (value.equals("TruffleInstrumentBranchesPretty")) {
            return OptionDescriptor.create("TruffleInstrumentBranchesPretty", Boolean.class, "Prettify stack traces for branch-instrumented callsites.", TruffleCompilerOptions.class, "TruffleInstrumentBranchesPretty", TruffleCompilerOptions.TruffleInstrumentBranchesPretty);
        }
        if (value.equals("TruffleInstrumentFilter")) {
            return OptionDescriptor.create("TruffleInstrumentFilter", String.class, "Method filter for host methods in which to add instrumentation.", TruffleCompilerOptions.class, "TruffleInstrumentFilter", TruffleCompilerOptions.TruffleInstrumentFilter);
        }
        if (value.equals("TruffleInstrumentationTableSize")) {
            return OptionDescriptor.create("TruffleInstrumentationTableSize", Integer.class, "Maximum number of instrumentation counters available.", TruffleCompilerOptions.class, "TruffleInstrumentationTableSize", TruffleCompilerOptions.TruffleInstrumentationTableSize);
        }
        if (value.equals("TruffleInvalidationReprofileCount")) {
            return OptionDescriptor.create("TruffleInvalidationReprofileCount", Integer.class, "Delay compilation after an invalidation to allow for reprofiling", TruffleCompilerOptions.class, "TruffleInvalidationReprofileCount", TruffleCompilerOptions.TruffleInvalidationReprofileCount);
        }
        if (value.equals("TruffleIterativePartialEscape")) {
            return OptionDescriptor.create("TruffleIterativePartialEscape", Boolean.class, "Run the partial escape analysis iteratively in Truffle compilation.", TruffleCompilerOptions.class, "TruffleIterativePartialEscape", TruffleCompilerOptions.TruffleIterativePartialEscape);
        }
        if (value.equals("TruffleMaximumRecursiveInlining")) {
            return OptionDescriptor.create("TruffleMaximumRecursiveInlining", Integer.class, "Maximum level of recursive inlining", TruffleCompilerOptions.class, "TruffleMaximumRecursiveInlining", TruffleCompilerOptions.TruffleMaximumRecursiveInlining);
        }
        if (value.equals("TruffleMinInvokeThreshold")) {
            return OptionDescriptor.create("TruffleMinInvokeThreshold", Integer.class, "Minimum number of calls before a call target is compiled", TruffleCompilerOptions.class, "TruffleMinInvokeThreshold", TruffleCompilerOptions.TruffleMinInvokeThreshold);
        }
        if (value.equals("TruffleOSR")) {
            return OptionDescriptor.create("TruffleOSR", Boolean.class, "Enable on stack replacement for Truffle loops.", TruffleCompilerOptions.class, "TruffleOSR", TruffleCompilerOptions.TruffleOSR);
        }
        if (value.equals("TruffleOSRCompilationThreshold")) {
            return OptionDescriptor.create("TruffleOSRCompilationThreshold", Integer.class, "Number of loop iterations until on-stack-replacement compilation is triggered.", TruffleCompilerOptions.class, "TruffleOSRCompilationThreshold", TruffleCompilerOptions.TruffleOSRCompilationThreshold);
        }
        if (value.equals("TrufflePerformanceWarningsAreFatal")) {
            return OptionDescriptor.create("TrufflePerformanceWarningsAreFatal", Boolean.class, "Treat performance warnings as fatal occurrences that will exit the applications", TruffleCompilerOptions.class, "TrufflePerformanceWarningsAreFatal", TruffleCompilerOptions.TrufflePerformanceWarningsAreFatal);
        }
        if (value.equals("TruffleProfilingEnabled")) {
            return OptionDescriptor.create("TruffleProfilingEnabled", Boolean.class, "Enable/disable builtin profiles in com.oracle.truffle.api.profiles.", TruffleCompilerOptions.class, "TruffleProfilingEnabled", TruffleCompilerOptions.TruffleProfilingEnabled);
        }
        if (value.equals("TruffleReplaceReprofileCount")) {
            return OptionDescriptor.create("TruffleReplaceReprofileCount", Integer.class, "Delay compilation after a node replacement", TruffleCompilerOptions.class, "TruffleReplaceReprofileCount", TruffleCompilerOptions.TruffleReplaceReprofileCount);
        }
        if (value.equals("TruffleReturnTypeSpeculation")) {
            return OptionDescriptor.create("TruffleReturnTypeSpeculation", Boolean.class, "", TruffleCompilerOptions.class, "TruffleReturnTypeSpeculation", TruffleCompilerOptions.TruffleReturnTypeSpeculation);
        }
        if (value.equals("TruffleSplitting")) {
            return OptionDescriptor.create("TruffleSplitting", Boolean.class, "Enable call target splitting", TruffleCompilerOptions.class, "TruffleSplitting", TruffleCompilerOptions.TruffleSplitting);
        }
        if (value.equals("TruffleSplittingMaxCalleeSize")) {
            return OptionDescriptor.create("TruffleSplittingMaxCalleeSize", Integer.class, "Disable call target splitting if tree size exceeds this limit", TruffleCompilerOptions.class, "TruffleSplittingMaxCalleeSize", TruffleCompilerOptions.TruffleSplittingMaxCalleeSize);
        }
        if (value.equals("TruffleTimeThreshold")) {
            return OptionDescriptor.create("TruffleTimeThreshold", Integer.class, "Defines the maximum timespan in milliseconds that is required for a call target to be queued for compilation.", TruffleCompilerOptions.class, "TruffleTimeThreshold", TruffleCompilerOptions.TruffleTimeThreshold);
        }
        if (value.equals("TruffleUseFrameWithoutBoxing")) {
            return OptionDescriptor.create("TruffleUseFrameWithoutBoxing", Boolean.class, "", TruffleCompilerOptions.class, "TruffleUseFrameWithoutBoxing", TruffleCompilerOptions.TruffleUseFrameWithoutBoxing);
        }
        // CheckStyle: resume line length check
        return null;
    }

    @Override
    public Iterator<OptionDescriptor> iterator() {
        // CheckStyle: stop line length check
        List<OptionDescriptor> options = Arrays.asList(
            OptionDescriptor.create("PrintTruffleExpansionHistogram", Boolean.class, "Prints a histogram of all expanded Java methods.", TruffleCompilerOptions.class, "PrintTruffleExpansionHistogram", TruffleCompilerOptions.PrintTruffleExpansionHistogram),
            OptionDescriptor.create("TraceTruffleAssumptions", Boolean.class, "Print stack trace on assumption invalidation", TruffleCompilerOptions.class, "TraceTruffleAssumptions", TruffleCompilerOptions.TraceTruffleAssumptions),
            OptionDescriptor.create("TraceTruffleCompilation", Boolean.class, "Print information for compilation results", TruffleCompilerOptions.class, "TraceTruffleCompilation", TruffleCompilerOptions.TraceTruffleCompilation),
            OptionDescriptor.create("TraceTruffleCompilationAST", Boolean.class, "Print all polymorphic and generic nodes after each compilation", TruffleCompilerOptions.class, "TraceTruffleCompilationAST", TruffleCompilerOptions.TraceTruffleCompilationAST),
            OptionDescriptor.create("TraceTruffleCompilationCallTree", Boolean.class, "Print the inlined call tree for each compiled method", TruffleCompilerOptions.class, "TraceTruffleCompilationCallTree", TruffleCompilerOptions.TraceTruffleCompilationCallTree),
            OptionDescriptor.create("TraceTruffleCompilationDetails", Boolean.class, "Print information for compilation queuing", TruffleCompilerOptions.class, "TraceTruffleCompilationDetails", TruffleCompilerOptions.TraceTruffleCompilationDetails),
            OptionDescriptor.create("TraceTruffleCompilationPolymorphism", Boolean.class, "Print all polymorphic and generic nodes after each compilation", TruffleCompilerOptions.class, "TraceTruffleCompilationPolymorphism", TruffleCompilerOptions.TraceTruffleCompilationPolymorphism),
            OptionDescriptor.create("TraceTruffleExpansionSource", Boolean.class, "Print source secions for printed expansion trees", TruffleCompilerOptions.class, "TraceTruffleExpansionSource", TruffleCompilerOptions.TraceTruffleExpansionSource),
            OptionDescriptor.create("TraceTruffleInlining", Boolean.class, "Print information for inlining for each compilation.", TruffleCompilerOptions.class, "TraceTruffleInlining", TruffleCompilerOptions.TraceTruffleInlining),
            OptionDescriptor.create("TraceTrufflePerformanceWarnings", Boolean.class, "Print potential performance problems", TruffleCompilerOptions.class, "TraceTrufflePerformanceWarnings", TruffleCompilerOptions.TraceTrufflePerformanceWarnings),
            OptionDescriptor.create("TraceTruffleSplitting", Boolean.class, "Print information for each splitted call site.", TruffleCompilerOptions.class, "TraceTruffleSplitting", TruffleCompilerOptions.TraceTruffleSplitting),
            OptionDescriptor.create("TraceTruffleStackTraceLimit", Integer.class, "Number of stack trace elements printed by TraceTruffleTransferToInterpreter and TraceTruffleAssumptions", TruffleCompilerOptions.class, "TraceTruffleStackTraceLimit", TruffleCompilerOptions.TraceTruffleStackTraceLimit),
            OptionDescriptor.create("TraceTruffleTransferToInterpreter", Boolean.class, "Print stack trace on transfer to interpreter", TruffleCompilerOptions.class, "TraceTruffleTransferToInterpreter", TruffleCompilerOptions.TraceTruffleTransferToInterpreter),
            OptionDescriptor.create("TruffleArgumentTypeSpeculation", Boolean.class, "", TruffleCompilerOptions.class, "TruffleArgumentTypeSpeculation", TruffleCompilerOptions.TruffleArgumentTypeSpeculation),
            OptionDescriptor.create("TruffleBackgroundCompilation", Boolean.class, "Enable asynchronous truffle compilation in background thread", TruffleCompilerOptions.class, "TruffleBackgroundCompilation", TruffleCompilerOptions.TruffleBackgroundCompilation),
            OptionDescriptor.create("TruffleCallTargetProfiling", Boolean.class, "Print a summary of execution counts for all executed CallTargets. Introduces counter overhead for each call.", TruffleCompilerOptions.class, "TruffleCallTargetProfiling", TruffleCompilerOptions.TruffleCallTargetProfiling),
            OptionDescriptor.create("TruffleCompilationExceptionsAreFatal", Boolean.class, "Treat compilation exceptions as fatal exceptions that will exit the application", TruffleCompilerOptions.class, "TruffleCompilationExceptionsAreFatal", TruffleCompilerOptions.TruffleCompilationExceptionsAreFatal),
            OptionDescriptor.create("TruffleCompilationExceptionsArePrinted", Boolean.class, "Prints the exception stack trace for compilation exceptions", TruffleCompilerOptions.class, "TruffleCompilationExceptionsArePrinted", TruffleCompilerOptions.TruffleCompilationExceptionsArePrinted),
            OptionDescriptor.create("TruffleCompilationExceptionsAreThrown", Boolean.class, "Treat compilation exceptions as thrown runtime exceptions", TruffleCompilerOptions.class, "TruffleCompilationExceptionsAreThrown", TruffleCompilerOptions.TruffleCompilationExceptionsAreThrown),
            OptionDescriptor.create("TruffleCompilationRepeats", Integer.class, "Compile time benchmarking: repeat Truffle compilation n times and then exit the VM", TruffleCompilerOptions.class, "TruffleCompilationRepeats", TruffleCompilerOptions.TruffleCompilationRepeats),
            OptionDescriptor.create("TruffleCompilationStatisticDetails", Boolean.class, "Print additional more verbose Truffle compilation statistics at the end of a run.", TruffleCompilerOptions.class, "TruffleCompilationStatisticDetails", TruffleCompilerOptions.TruffleCompilationStatisticDetails),
            OptionDescriptor.create("TruffleCompilationStatistics", Boolean.class, "Print Truffle compilation statistics at the end of a run.", TruffleCompilerOptions.class, "TruffleCompilationStatistics", TruffleCompilerOptions.TruffleCompilationStatistics),
            OptionDescriptor.create("TruffleCompilationThreshold", Integer.class, "Compile call target when call count exceeds this threshold", TruffleCompilerOptions.class, "TruffleCompilationThreshold", TruffleCompilerOptions.TruffleCompilationThreshold),
            OptionDescriptor.create("TruffleCompileImmediately", Boolean.class, "Compile immediately to test truffle compiler", TruffleCompilerOptions.class, "TruffleCompileImmediately", TruffleCompilerOptions.TruffleCompileImmediately),
            OptionDescriptor.create("TruffleCompileOnly", String.class, "Restrict compilation to comma-separated list of includes (or excludes prefixed with tilde)", TruffleCompilerOptions.class, "TruffleCompileOnly", TruffleCompilerOptions.TruffleCompileOnly),
            OptionDescriptor.create("TruffleCompilerThreads", Integer.class, "Manually set the number of compiler threads", TruffleCompilerOptions.class, "TruffleCompilerThreads", TruffleCompilerOptions.TruffleCompilerThreads),
            OptionDescriptor.create("TruffleEnableInfopoints", Boolean.class, "Enable support for simple infopoints in truffle partial evaluations.", TruffleCompilerOptions.class, "TruffleEnableInfopoints", TruffleCompilerOptions.TruffleEnableInfopoints),
            OptionDescriptor.create("TruffleExcludeAssertions", Boolean.class, "Exclude assertion code from Truffle compilations", TruffleCompilerOptions.class, "TruffleExcludeAssertions", TruffleCompilerOptions.TruffleExcludeAssertions),
            OptionDescriptor.create("TruffleFunctionInlining", Boolean.class, "Enable automatic inlining of call targets", TruffleCompilerOptions.class, "TruffleFunctionInlining", TruffleCompilerOptions.TruffleFunctionInlining),
            OptionDescriptor.create("TruffleInlineAcrossTruffleBoundary", Boolean.class, "Enable inlining across Truffle boundary", TruffleCompilerOptions.class, "TruffleInlineAcrossTruffleBoundary", TruffleCompilerOptions.TruffleInlineAcrossTruffleBoundary),
            OptionDescriptor.create("TruffleInliningMaxCallerSize", Integer.class, "Stop inlining if caller's cumulative tree size would exceed this limit", TruffleCompilerOptions.class, "TruffleInliningMaxCallerSize", TruffleCompilerOptions.TruffleInliningMaxCallerSize),
            OptionDescriptor.create("TruffleInstrumentBoundaries", Boolean.class, "Instrument Truffle boundaries and output profiling information to the standard output.", TruffleCompilerOptions.class, "TruffleInstrumentBoundaries", TruffleCompilerOptions.TruffleInstrumentBoundaries),
            OptionDescriptor.create("TruffleInstrumentBoundariesPerInlineSite", Boolean.class, "Instrument Truffle boundaries by considering different inlining sites as different branches.", TruffleCompilerOptions.class, "TruffleInstrumentBoundariesPerInlineSite", TruffleCompilerOptions.TruffleInstrumentBoundariesPerInlineSite),
            OptionDescriptor.create("TruffleInstrumentBranches", Boolean.class, "Instrument branches and output profiling information to the standard output.", TruffleCompilerOptions.class, "TruffleInstrumentBranches", TruffleCompilerOptions.TruffleInstrumentBranches),
            OptionDescriptor.create("TruffleInstrumentBranchesCount", Integer.class, "Maximum number of instrumentation counters available.", TruffleCompilerOptions.class, "TruffleInstrumentBranchesCount", TruffleCompilerOptions.TruffleInstrumentBranchesCount),
            OptionDescriptor.create("TruffleInstrumentBranchesFilter", String.class, "Method filter for methods in which to add branch instrumentation.", TruffleCompilerOptions.class, "TruffleInstrumentBranchesFilter", TruffleCompilerOptions.TruffleInstrumentBranchesFilter),
            OptionDescriptor.create("TruffleInstrumentBranchesPerInlineSite", Boolean.class, "Instrument branches by considering different inlining sites as different branches.", TruffleCompilerOptions.class, "TruffleInstrumentBranchesPerInlineSite", TruffleCompilerOptions.TruffleInstrumentBranchesPerInlineSite),
            OptionDescriptor.create("TruffleInstrumentBranchesPretty", Boolean.class, "Prettify stack traces for branch-instrumented callsites.", TruffleCompilerOptions.class, "TruffleInstrumentBranchesPretty", TruffleCompilerOptions.TruffleInstrumentBranchesPretty),
            OptionDescriptor.create("TruffleInstrumentFilter", String.class, "Method filter for host methods in which to add instrumentation.", TruffleCompilerOptions.class, "TruffleInstrumentFilter", TruffleCompilerOptions.TruffleInstrumentFilter),
            OptionDescriptor.create("TruffleInstrumentationTableSize", Integer.class, "Maximum number of instrumentation counters available.", TruffleCompilerOptions.class, "TruffleInstrumentationTableSize", TruffleCompilerOptions.TruffleInstrumentationTableSize),
            OptionDescriptor.create("TruffleInvalidationReprofileCount", Integer.class, "Delay compilation after an invalidation to allow for reprofiling", TruffleCompilerOptions.class, "TruffleInvalidationReprofileCount", TruffleCompilerOptions.TruffleInvalidationReprofileCount),
            OptionDescriptor.create("TruffleIterativePartialEscape", Boolean.class, "Run the partial escape analysis iteratively in Truffle compilation.", TruffleCompilerOptions.class, "TruffleIterativePartialEscape", TruffleCompilerOptions.TruffleIterativePartialEscape),
            OptionDescriptor.create("TruffleMaximumRecursiveInlining", Integer.class, "Maximum level of recursive inlining", TruffleCompilerOptions.class, "TruffleMaximumRecursiveInlining", TruffleCompilerOptions.TruffleMaximumRecursiveInlining),
            OptionDescriptor.create("TruffleMinInvokeThreshold", Integer.class, "Minimum number of calls before a call target is compiled", TruffleCompilerOptions.class, "TruffleMinInvokeThreshold", TruffleCompilerOptions.TruffleMinInvokeThreshold),
            OptionDescriptor.create("TruffleOSR", Boolean.class, "Enable on stack replacement for Truffle loops.", TruffleCompilerOptions.class, "TruffleOSR", TruffleCompilerOptions.TruffleOSR),
            OptionDescriptor.create("TruffleOSRCompilationThreshold", Integer.class, "Number of loop iterations until on-stack-replacement compilation is triggered.", TruffleCompilerOptions.class, "TruffleOSRCompilationThreshold", TruffleCompilerOptions.TruffleOSRCompilationThreshold),
            OptionDescriptor.create("TrufflePerformanceWarningsAreFatal", Boolean.class, "Treat performance warnings as fatal occurrences that will exit the applications", TruffleCompilerOptions.class, "TrufflePerformanceWarningsAreFatal", TruffleCompilerOptions.TrufflePerformanceWarningsAreFatal),
            OptionDescriptor.create("TruffleProfilingEnabled", Boolean.class, "Enable/disable builtin profiles in com.oracle.truffle.api.profiles.", TruffleCompilerOptions.class, "TruffleProfilingEnabled", TruffleCompilerOptions.TruffleProfilingEnabled),
            OptionDescriptor.create("TruffleReplaceReprofileCount", Integer.class, "Delay compilation after a node replacement", TruffleCompilerOptions.class, "TruffleReplaceReprofileCount", TruffleCompilerOptions.TruffleReplaceReprofileCount),
            OptionDescriptor.create("TruffleReturnTypeSpeculation", Boolean.class, "", TruffleCompilerOptions.class, "TruffleReturnTypeSpeculation", TruffleCompilerOptions.TruffleReturnTypeSpeculation),
            OptionDescriptor.create("TruffleSplitting", Boolean.class, "Enable call target splitting", TruffleCompilerOptions.class, "TruffleSplitting", TruffleCompilerOptions.TruffleSplitting),
            OptionDescriptor.create("TruffleSplittingMaxCalleeSize", Integer.class, "Disable call target splitting if tree size exceeds this limit", TruffleCompilerOptions.class, "TruffleSplittingMaxCalleeSize", TruffleCompilerOptions.TruffleSplittingMaxCalleeSize),
            OptionDescriptor.create("TruffleTimeThreshold", Integer.class, "Defines the maximum timespan in milliseconds that is required for a call target to be queued for compilation.", TruffleCompilerOptions.class, "TruffleTimeThreshold", TruffleCompilerOptions.TruffleTimeThreshold),
            OptionDescriptor.create("TruffleUseFrameWithoutBoxing", Boolean.class, "", TruffleCompilerOptions.class, "TruffleUseFrameWithoutBoxing", TruffleCompilerOptions.TruffleUseFrameWithoutBoxing)
        );
        // CheckStyle: resume line length check
        return options.iterator();
    }
}
