// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// Source: TruffleGraphBuilderPlugins.java
package org.graalvm.compiler.truffle.substitutions;

import java.util.*;
import org.graalvm.compiler.options.*;

public class TruffleGraphBuilderPlugins_OptionDescriptors implements OptionDescriptors {
    @Override
    public OptionDescriptor get(String value) {
        // CheckStyle: stop line length check
        if (value.equals("TruffleIntrinsifyFrameAccess")) {
            return OptionDescriptor.create("TruffleIntrinsifyFrameAccess", Boolean.class, "Intrinsify get/set/is methods of FrameWithoutBoxing to improve Truffle compilation time", TruffleGraphBuilderPlugins.Options.class, "TruffleIntrinsifyFrameAccess", TruffleGraphBuilderPlugins.Options.TruffleIntrinsifyFrameAccess);
        }
        // CheckStyle: resume line length check
        return null;
    }

    @Override
    public Iterator<OptionDescriptor> iterator() {
        // CheckStyle: stop line length check
        List<OptionDescriptor> options = Arrays.asList(
            OptionDescriptor.create("TruffleIntrinsifyFrameAccess", Boolean.class, "Intrinsify get/set/is methods of FrameWithoutBoxing to improve Truffle compilation time", TruffleGraphBuilderPlugins.Options.class, "TruffleIntrinsifyFrameAccess", TruffleGraphBuilderPlugins.Options.TruffleIntrinsifyFrameAccess)
        );
        // CheckStyle: resume line length check
        return options.iterator();
    }
}
