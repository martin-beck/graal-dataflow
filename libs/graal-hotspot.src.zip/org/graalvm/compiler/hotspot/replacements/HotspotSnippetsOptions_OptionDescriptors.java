// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// Source: HotspotSnippetsOptions.java
package org.graalvm.compiler.hotspot.replacements;

import java.util.*;
import org.graalvm.compiler.options.*;

public class HotspotSnippetsOptions_OptionDescriptors implements OptionDescriptors {
    @Override
    public OptionDescriptor get(String value) {
        // CheckStyle: stop line length check
        if (value.equals("LoadExceptionObjectInVM")) {
            return OptionDescriptor.create("LoadExceptionObjectInVM", Boolean.class, "Use a VM runtime call to load and clear the exception object from the thread at the start of a compiled exception handler.", HotspotSnippetsOptions.class, "LoadExceptionObjectInVM", HotspotSnippetsOptions.LoadExceptionObjectInVM);
        }
        if (value.equals("ProfileAllocations")) {
            return OptionDescriptor.create("ProfileAllocations", Boolean.class, "Enable profiling of allocation sites.", HotspotSnippetsOptions.class, "ProfileAllocations", HotspotSnippetsOptions.ProfileAllocations);
        }
        if (value.equals("ProfileAllocationsContext")) {
            return OptionDescriptor.create("ProfileAllocationsContext", org.graalvm.compiler.hotspot.replacements.NewObjectSnippets.ProfileContext.class, "Control the naming of the counters when using ProfileAllocations.", HotspotSnippetsOptions.class, "ProfileAllocationsContext", HotspotSnippetsOptions.ProfileAllocationsContext);
        }
        if (value.equals("ProfileMonitors")) {
            return OptionDescriptor.create("ProfileMonitors", Boolean.class, "Enable profiling of monitor operations.", HotspotSnippetsOptions.class, "ProfileMonitors", HotspotSnippetsOptions.ProfileMonitors);
        }
        if (value.equals("SimpleFastInflatedLocking")) {
            return OptionDescriptor.create("SimpleFastInflatedLocking", Boolean.class, "Handle simple cases for inflated monitors in the fast-path.", HotspotSnippetsOptions.class, "SimpleFastInflatedLocking", HotspotSnippetsOptions.SimpleFastInflatedLocking);
        }
        if (value.equals("TraceMonitorsMethodFilter")) {
            return OptionDescriptor.create("TraceMonitorsMethodFilter", String.class, "Trace monitor operations in methods whose fully qualified name contains this substring.", HotspotSnippetsOptions.class, "TraceMonitorsMethodFilter", HotspotSnippetsOptions.TraceMonitorsMethodFilter);
        }
        if (value.equals("TraceMonitorsTypeFilter")) {
            return OptionDescriptor.create("TraceMonitorsTypeFilter", String.class, "Trace monitor operations on objects whose type contains this substring.", HotspotSnippetsOptions.class, "TraceMonitorsTypeFilter", HotspotSnippetsOptions.TraceMonitorsTypeFilter);
        }
        if (value.equals("TypeCheckMaxHints")) {
            return OptionDescriptor.create("TypeCheckMaxHints", Integer.class, "The maximum number of profiled types that will be used when compiling a profiled type check. Note that TypeCheckMinProfileHitProbability also influences whether profiling info is used in compiled type checks.", HotspotSnippetsOptions.class, "TypeCheckMaxHints", HotspotSnippetsOptions.TypeCheckMaxHints);
        }
        if (value.equals("TypeCheckMinProfileHitProbability")) {
            return OptionDescriptor.create("TypeCheckMinProfileHitProbability", Double.class, "If the probability that a type check will hit one the profiled types (up to TypeCheckMaxHints) is below this value, the type check will be compiled without profiling info", HotspotSnippetsOptions.class, "TypeCheckMinProfileHitProbability", HotspotSnippetsOptions.TypeCheckMinProfileHitProbability);
        }
        if (value.equals("VerifyBalancedMonitors")) {
            return OptionDescriptor.create("VerifyBalancedMonitors", Boolean.class, "Emit extra code to dynamically check monitor operations are balanced.", HotspotSnippetsOptions.class, "VerifyBalancedMonitors", HotspotSnippetsOptions.VerifyBalancedMonitors);
        }
        // CheckStyle: resume line length check
        return null;
    }

    @Override
    public Iterator<OptionDescriptor> iterator() {
        // CheckStyle: stop line length check
        List<OptionDescriptor> options = Arrays.asList(
            OptionDescriptor.create("LoadExceptionObjectInVM", Boolean.class, "Use a VM runtime call to load and clear the exception object from the thread at the start of a compiled exception handler.", HotspotSnippetsOptions.class, "LoadExceptionObjectInVM", HotspotSnippetsOptions.LoadExceptionObjectInVM),
            OptionDescriptor.create("ProfileAllocations", Boolean.class, "Enable profiling of allocation sites.", HotspotSnippetsOptions.class, "ProfileAllocations", HotspotSnippetsOptions.ProfileAllocations),
            OptionDescriptor.create("ProfileAllocationsContext", org.graalvm.compiler.hotspot.replacements.NewObjectSnippets.ProfileContext.class, "Control the naming of the counters when using ProfileAllocations.", HotspotSnippetsOptions.class, "ProfileAllocationsContext", HotspotSnippetsOptions.ProfileAllocationsContext),
            OptionDescriptor.create("ProfileMonitors", Boolean.class, "Enable profiling of monitor operations.", HotspotSnippetsOptions.class, "ProfileMonitors", HotspotSnippetsOptions.ProfileMonitors),
            OptionDescriptor.create("SimpleFastInflatedLocking", Boolean.class, "Handle simple cases for inflated monitors in the fast-path.", HotspotSnippetsOptions.class, "SimpleFastInflatedLocking", HotspotSnippetsOptions.SimpleFastInflatedLocking),
            OptionDescriptor.create("TraceMonitorsMethodFilter", String.class, "Trace monitor operations in methods whose fully qualified name contains this substring.", HotspotSnippetsOptions.class, "TraceMonitorsMethodFilter", HotspotSnippetsOptions.TraceMonitorsMethodFilter),
            OptionDescriptor.create("TraceMonitorsTypeFilter", String.class, "Trace monitor operations on objects whose type contains this substring.", HotspotSnippetsOptions.class, "TraceMonitorsTypeFilter", HotspotSnippetsOptions.TraceMonitorsTypeFilter),
            OptionDescriptor.create("TypeCheckMaxHints", Integer.class, "The maximum number of profiled types that will be used when compiling a profiled type check. Note that TypeCheckMinProfileHitProbability also influences whether profiling info is used in compiled type checks.", HotspotSnippetsOptions.class, "TypeCheckMaxHints", HotspotSnippetsOptions.TypeCheckMaxHints),
            OptionDescriptor.create("TypeCheckMinProfileHitProbability", Double.class, "If the probability that a type check will hit one the profiled types (up to TypeCheckMaxHints) is below this value, the type check will be compiled without profiling info", HotspotSnippetsOptions.class, "TypeCheckMinProfileHitProbability", HotspotSnippetsOptions.TypeCheckMinProfileHitProbability),
            OptionDescriptor.create("VerifyBalancedMonitors", Boolean.class, "Emit extra code to dynamically check monitor operations are balanced.", HotspotSnippetsOptions.class, "VerifyBalancedMonitors", HotspotSnippetsOptions.VerifyBalancedMonitors)
        );
        // CheckStyle: resume line length check
        return options.iterator();
    }
}
