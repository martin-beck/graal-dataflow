// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// Source: OnStackReplacementPhase.java
package org.graalvm.compiler.hotspot.phases;

import java.util.*;
import org.graalvm.compiler.options.*;

public class OnStackReplacementPhase_OptionDescriptors implements OptionDescriptors {
    @Override
    public OptionDescriptor get(String value) {
        // CheckStyle: stop line length check
        if (value.equals("DeoptAfterOSR")) {
            return OptionDescriptor.create("DeoptAfterOSR", Boolean.class, "Deoptimize OSR compiled code when the OSR entry loop is finished if there is no mature profile available for the rest of the method.", OnStackReplacementPhase.Options.class, "DeoptAfterOSR", OnStackReplacementPhase.Options.DeoptAfterOSR);
        }
        if (value.equals("SupportOSRWithLocks")) {
            return OptionDescriptor.create("SupportOSRWithLocks", Boolean.class, "Support OSR compilations with locks. If DeoptAfterOSR is true we can per definition not have unbalaced enter/extis mappings. If DeoptAfterOSR is false insert artificial monitor enters after the OSRStart to have balanced enter/exits in the graph.", OnStackReplacementPhase.Options.class, "SupportOSRWithLocks", OnStackReplacementPhase.Options.SupportOSRWithLocks);
        }
        // CheckStyle: resume line length check
        return null;
    }

    @Override
    public Iterator<OptionDescriptor> iterator() {
        // CheckStyle: stop line length check
        List<OptionDescriptor> options = Arrays.asList(
            OptionDescriptor.create("DeoptAfterOSR", Boolean.class, "Deoptimize OSR compiled code when the OSR entry loop is finished if there is no mature profile available for the rest of the method.", OnStackReplacementPhase.Options.class, "DeoptAfterOSR", OnStackReplacementPhase.Options.DeoptAfterOSR),
            OptionDescriptor.create("SupportOSRWithLocks", Boolean.class, "Support OSR compilations with locks. If DeoptAfterOSR is true we can per definition not have unbalaced enter/extis mappings. If DeoptAfterOSR is false insert artificial monitor enters after the OSRStart to have balanced enter/exits in the graph.", OnStackReplacementPhase.Options.class, "SupportOSRWithLocks", OnStackReplacementPhase.Options.SupportOSRWithLocks)
        );
        // CheckStyle: resume line length check
        return options.iterator();
    }
}
